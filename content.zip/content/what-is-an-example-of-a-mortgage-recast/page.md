Original URL: https://azmortgagebrothers.com/what-is-an-example-of-a-mortgage-recast/
Page Title: What Is a Mortgage Recast? Example & Benefits Explained
Meta Title: What is an Example of a Mortgage Recast?
Meta Description: See a clear mortgage recast example, how lump-sum payments lower monthly payments, and when paying down principal without a recast is better.
Canonical URL: https://azmortgagebrothers.com/what-is-an-example-of-a-mortgage-recast/
H1: What is an Example of a Mortgage Recast?

by

| Feb 4, 2025

In this episode, we covered mortgage recasts. Normally, this question comes up when a borrower has newly come into a lump sum of money, be it from a recent inheritance, a bonus, or through selling a house, and are interested in a principal reduction.

There two common ways of dealing with the new influx of cash: 1) Recasting your mortgage, 2) Paying down on the principal without a recast

Don’t Let a Late Payment Hold You Back!

Even with a mortgage late in the past year, approval is still possible. Learn how you can navigate the process and get expert advice tailored to your situation.

Get Personalized Help Now

## What is a mortgage recast?

Unlike a traditional refinance, with a recast you are basically going into an existing loan, opening it up, and redoing it without starting from scratch.

Let’s say you just came into $100,000 and you started with a $300,000 mortgage. When doing a recast, you would put this $100,000 down toward the principal. You’d tell the bank you’d want to do a recast and they would reduce the balance from $300,000 to $200,000. The time remaining on the loan would remain the same, but your monthly payment would go down which, as a result, would decrease the amount of interest you owe over the term of the loan.

It’s important to note that with recasts neither your interest rate nor the number of years left on the loan will change. It is the loan amount that changes in a recast, no the loan itself. As well, you’ll typically need to have a couple of months of payments under your belt. As a rule of thumb, we recommend at least two. You also can’t just give the bank a $5000 principal reduction and ask for a recast. They will usually require a minimum of $10,000 and some banks will limit you to one recast a year, and just a couple over the lifetime of the loan. You should also expect there to be a fee between, usually, $200 and $300, though it varies from bank to bank.

But it should be noted that because this is not a refinance, there are no appraisals and you don’t have to go through an approval process. There’s just going to be an administrative fee.

If you’re interested in recast, be sure to check with your servicing bank on their rules and whether or not they allow for recasts.

## What if you just pay your mortgage?

Say you put the $100,000 down against the $300,000 but you don’t recast. In this case, the bank would apply this to your monthly balance. They would keep your payments the same but the timeline of your mortgage payoff would be accelerated, and as a result, the interest you will end up owing will decrease over time because you would have reduced the number of payments that are left.

## When is it right to do a mortgage recast versus just paying down against your mortgage?

A recast is more so for someone who’s on a fixed budget, or fixed income, and they strategically need to get within a certain dollar amount per month. Typically, people who come to us with some extra money will usually decide to simply pay off their mortgage earlier.

If you have any questions about this or if you have any questions you’d like us to answer on our podcast, you can submit your questions using our contact form or give us a call at(602) 535-2171. Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

•••

Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

Mortgage Brothers LLC does not provide tax, legal, or accounting advice. This material has been prepared for informational purposes only. You should consult your own tax, legal, and accounting advisors before engaging in any transaction. Mortgage Brothers NMLS 1007154, NMLS #210917 and 1618695. Equal housing lender.

Dive into a clear example of a mortgage recast and see how it works. Additionally, learn about delayed financing, explore the advantages of an assumable mortgage, discover options for cash offer financing, and check out the FHA flip rule waiver.

---

## Transcript of the Mortgage Brothers Podcast

### What is a Mortgage Recast? A Clear Example

### Introduction

[00:02]Welcome to the Mortgage Brothers Podcast! I’m Eddie Knoell, and I’m Tom Knoell. In this episode, we’re diving into mortgage recasting—a topic many homeowners ask about.

- What exactly is a mortgage recast?
- How does it compare to a refinance?
- Who can benefit from a recast?

Let’s break it down with a real-life example!

### Mortgage Recast vs. Refinance: What’s the Difference?

[01:16]Homeowners looking to adjust their mortgage payments typically consider two main options:

1️⃣ Refinance – Completely replaces your current loan with a new one, which may involve:

- A different interest rate
- New loan terms (e.g., switching from a 30-year to a 15-year loan)
- A brand-new loan amount

2️⃣ Recast – Instead of replacing your loan, you apply a lump sum payment toward your principal, and your lender recalculates your monthly payments based on the new, lower balance.

- No new loan terms
- No change in interest rate
- Simply lowers your monthly payment

💡 Key Takeaway: A recast keeps your existing loan but reduces your monthly mortgage payment after you apply a lump sum toward the principal.

### When Does a Mortgage Recast Make Sense?

[02:25]A mortgage recast is best suited for homeowners who:✅ Have a large sum of money coming in (e.g., inheritance, work bonus, home sale proceeds).✅ Want to reduce monthly payments without refinancing.✅ Have a low interest rate on their current mortgage and don’t want to lose it by refinancing.✅ Prefer to avoid the costs and paperwork of refinancing.

Example: A borrower receives a $100,000 inheritance and wants to lower their mortgage payments.

Now, let’s compare two scenarios—one with a recast and one without.

### Scenario 1: Recasting the Mortgage

[04:12]Loan Details (Before Recast):

- Original Loan: $300,000
- Monthly Payment: $1,264
- Remaining Term: 29 years

After Recasting (Applying $100,000 to Principal):

- New Loan Balance: $200,000
- New Monthly Payment: $861
- Term remains the same (29 years)
- Total Interest Saved: $55,000

✅ Benefits of a Recast:

- Lower monthly payment while keeping the same loan term.
- No change in interest rate—ideal if you already have a low rate.
- Minimal fees ($200–$300 vs. thousands in refinance costs).

### Scenario 2: Paying Down Principal Without Recasting

[06:00]What if the borrower just makes a lump sum payment but doesn’t request a recast?

- Original Loan: $300,000
- Lump Sum Payment: $100,000
- New Loan Balance: $200,000
- Monthly Payment: Remains at $1,264
- Mortgage is paid off in 17 years (instead of 29 years).
- Total Interest Saved: $95,000

✅ Benefits of Paying Down Principal Without a Recast:

- Pays off the mortgage years earlier.
- Saves more in interest over the life of the loan.

🚨 Biggest Difference:

- A recast lowers your monthly payment but keeps your term the same.
- Paying extra without a recast keeps your payments the same but pays off the loan faster.

### Who Should Choose a Mortgage Recast?

[08:37]A mortgage recast is best for homeowners who:✅ Need lower monthly payments due to a fixed income or budget constraints.✅ Are selling a home and buying another one—wanting to apply the proceeds toward their new mortgage.✅ Have a large sum of money but don’t necessarily want to pay off their mortgage early.

💡 Recast Example: Home Sale Proceeds

- Homeowner buys a new home before selling their old one.
- They take out a mortgage with a higher payment than they’d like.
- After selling the old home, they apply those proceeds toward the new mortgage and recast to lower the payment.

### How to Request a Mortgage Recast

[09:43]To qualify for a mortgage recast, you’ll need to:

1️⃣ Make at least two payments on your mortgage before applying.2️⃣ Have a lump sum (usually at least $10,000) to put toward principal.3️⃣ Check with your lender—some only allow a limited number of recasts.4️⃣ Pay a small administrative fee (typically $200–$300).

🚨 Important Notes:

- Not all lenders allow recasts. If this is part of your plan, ask your lender before closing on your mortgage.
- Government-backed loans (FHA, VA, USDA) do NOT allow recasts—only conventional loans typically qualify.

### Final Thoughts: Should You Recast or Just Pay Down Principal?

[12:09]✅ Choose a Mortgage Recast if:

- You need lower monthly payments.
- You don’t want to refinance and lose your current interest rate.
- You plan to stay in your home long-term.

✅ Choose to Pay Down Principal Without a Recast if:

- You want to pay off your mortgage faster.
- You can afford the current monthly payments.
- You want to maximize interest savings over time.

Both options have their advantages—it all depends on your financial goals.

### Need Mortgage Advice? Contact Us!

[12:40]If you’re considering a mortgage recast or refinancing, reach out to the Mortgage Brothers Team for a free consultation.

📞 Contact us: Contact Form📞 Call us for a personalized mortgage review

If you found this video helpful, like, subscribe, and hit the notification button for more mortgage insights. Thanks for tuning in!
