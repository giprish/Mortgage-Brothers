Original URL: https://azmortgagebrothers.com/connecting-guest-house-main-house-add-value/
Page Title: Does Connecting a Guest House to The Main House Add Values?
Meta Title: Does connecting a guest house to the main house add value?
Meta Description: Should You Connect a Guest House to the Main House? Here is Borrower’s question about connecting a detached guest house to his main house: “Looks like we will be staying here a bit longer and are thinking of doing some more things to make it nicer. We were thinking of adding a structure that connects
Canonical URL: https://azmortgagebrothers.com/connecting-guest-house-main-house-add-value/
H1: Does connecting a guest house to the main house add value?

## Should You Connect a Guest House to the Main House?

Here is Borrower’s question about connecting a detached guest house to his main house:

“Looks like we will be staying here a bit longer and are thinking of doing some more things to make it nicer. We were thinking of adding a structure that connects the house to the outside casita. It will have a connecting door making it part of the square footage of the house contrary to before when it was not counted as such.

5 months ago our house appraised at $440,000. The main house has 2,427 square feet. By connecting the detached guest house casita, the additional square footage will be 400 square feet and that would make the house about 2827 square feet. We are hoping that it increases the value by $30,000 or more.

Thinking About Connecting a Guest House?

Find out if connecting your guest house to the main home will increase value and appeal to buyers. Get expert insights today!

Get a Free Home Value Assessment

A few questions:

- If I add in the square footage for the NEW area, do I totally eliminate the value of the Casita on its own? It was valued at $15,600 or $60 a foot.
- OR do I keep a small value there for it because it is considered a “casita or mother in law room”?
- OR do I just go by the square footage of the whole house X the value per foot? 2,427 square feet X 181 = 440,000 then and now 2827 X 181 = 511,000?

So, all this brings me to this. If we refinanced again after the connection of the detached guest house casita is done, we would like to pull more money out (80% LTV) to cover the cost of the construction and then for other improvements around the house. Based on hypothetical values later and our credit scores being over 700, it would be something I would really like to do but need clarification of the supposed increase in value.

Can you help answer these questions?”

## My Answers and Expert Insights on Guest House Connection

Here are my answers

Make sure all additions go through the proper channels at the city level and get all permits etc.

The structure that connects the guest house and main house has to be livable space, closed in, etc. It cannot be just a structure connecting the house and casita.

If you are merely talking about a structure connecting the house and casita, your home would value would not change.

In other words, the city has to recognize that you have a single 2,827 square foot building. There cannot be any ‘grey area’ or possible misinterpretation by an appraiser who visits your property.

The casita becomes apart of the home. One structure and one value for all of it.

The future value of your home will depend on what comparable sales are with 2,800 square feet. If similar homes with 2,800 square feet livable space are selling for $180/square foot, yours should be worth that too.

Since the detached casita was appraised 5 months ago with a $60 per square foot value, a new appraisal giving you a value of $180 per square foot will increase your value an estimated $48,000 (I took the square foot price difference, $120 and multiplied it by 400 square feet). The only caveat I can think of is this, be sure to check the comparable sales at the larger square footage. If you look at your immediate area, typically large homes will be worth less per square foot.

It is common to see a 2,000 square foot home sell for $180 per square foot and a 3,000 square foot home in the same neighborhood sell for $170 per square foot. Value is not a straight line that is constant, there is a point where you will get diminished returns as you go larger in home size. Be sure to check and verify the recent sales within 6 months around your home.

Learn how linking a guest house to your main residence can add significant value to your property. You might also explore our analysis on the differences between owner-occupied second homes and investment properties, examine detached guest home appraisal issues, and understand the distinctions between Arizona condos and townhomes.
