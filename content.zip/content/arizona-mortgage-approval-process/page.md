Original URL: https://azmortgagebrothers.com/arizona-mortgage-approval-process/
Page Title: Simplify with Arizona Mortgage Approval Process
Meta Title: Learn About the Home Mortgage Approval Process
Meta Description: There's no question that the entire approval process for home loans in Arizona can be confusing and slightly overwhelming! For the first-time home buyer the process can be a stressful situation so we want to provide you a road map to help you navigate the event, but be sure that you always take the time.
Canonical URL: https://azmortgagebrothers.com/arizona-mortgage-approval-process/
H1: Learn About the Home Mortgage Approval Process

# Learn About the Home Mortgage Approval Process

There’s no question that the entire approval process for home loans in Arizona can be confusing and slightly overwhelming! For the first-time home buyer the process can be a stressful situation so we want to provide you a road map to help you navigate the event, but be sure that you always take the time to ask your Arizona mortgage broker if anything is unclear!

We’ve also placed at the bottom of this page a Frequently Asked Questions (FAQ) section for quick reference!

Mortgage loan program guidelines, Arizona mortgage rate questions and down payment requirements are a few of the major components you’ll need to be familiar with when applying for a home loan for your new purchase or for your refinance.

Master the Process—Connect with Our Experts!

Now that you understand the Arizona Mortgage Approval Process, reach out to us. We’re here to streamline your mortgage journey. https://azmortgagebrothers.com/if-i-have-1-mortgage-late-in-the-past-12-months-can-i-get-approved-for-a-mortgage/#Get-in-Touch

Contact Us Today

## Table of Contents

## Mortgage Approval Process Outline

### Step 1

Loan Officer takes your application. The application contains:

- Your legal name
- Address and where you have worked for the last 2 years
- Your asset and income documentation
- List of all properties that you own
- You will need to disclose whether you have had any collections, judgements, Bankruptcies, Foreclosures, etc.

### Step 2

The loan officer will pull your credit:

- The loan officer will pull your credit to determine what liabilities you have on a monthly basis and what credit score you have. The content of your credit report as well as the credit score will impact and affect your approval.

### Step 3

Your file is setup and then submitted your loan through the underwriter pre-approval process

- In most cases, this is a submitted through an online approval system. The two most widely used underwriting systems are ‘Desktop Underwriter‘ and ‘Loan Prospector‘
- The approval system will give the loan officer ‘findings’ which tell them if you are approved for the loan or not. The ‘findings’ will tell them specifically what they will need to document in your file.

### Step 4

You will be given a list of documents to provide the loan officer. Typically, this is what will be asked from you:

- Copies of your 2 most recent tax returns (federal returns only)
- 30 days of paystubs to document income
- 2 months bank statements (all pages) to document assets and reserves
- Copy of your drivers license
- In some cases you will need to provide a copy of your social security card
- Any letters of explanations that the loan officer believes will be asked for by the underwriter
- You will need to setup a homeowners insurance policy and give the insurance agent’s contact information to the loan officer

### Step 5

Your loan file is setup and then submitted to underwriting

- All your documents and supporting loan items are organized in a particular order for the underwriter to review for preliminary or final approval.

### Step 6

Your loan receive an approval either with or without conditions:

- In most cases there is something (extra documentation) that the underwriter will be asking the loan officer to gather for the file. This occurs on nearly 99% of all files and should be anticipated by the borrower.

### Step 7

Once all the required conditions are met, your file will receive a final approval:

- The lender will clear your file from underwriting.
- The lender will then prepare your loan documents to be sent to the title company.

### Step 8

The loan documents are sent to the tile company and your escrow officer prepares them for you to sign:

- You will make an appointment with the title company to sign your loan documents.
- After you sign the documents, the title company send the file to the Lender’s funder for review.

### Step 9

The funder reviews everything in the file and sends the wire:

- When the funder confirms that everything is in the file that the lender requires, they order the wire to be sent to the title company.
- The title company receives the wire and reconciles all their figures.

### Step 10

The title company records the purchase or refinance loan

- The home loan is complete and you can now relax.

## Beyond the Steps of the Mortgage Approval Process

As we mentioned in “Mortgage Basic”, Arizona mortgage lenders approve loans that are secured by the real estate being purchased but also based on a standard set of guidelines which are determined by the type of loan program you’re getting involved in. To help you understand the terminology you’ll be hearing, we have a few of those key components below.

## Debt to Income (DTI) Ratio

- This ratio is a comparison between a borrower’s income to their debt (or liabilities).
- The lower the ratio (that is, the higher your income is compared to the debts you have) the better it is. This gives confidence to the lender that you’ll be able to repay the loan.

## Loan to Value (LTV)

- A common term used by mortgage lenders, it compared the difference between the outstanding amount of the loan compared to the property’s value.
- Depending on this ratio, you may be required to have a higher down payment in order to avoid mortgage insurance. However, some government loan programs can be done with little to no down payment (or higher Loan to Value ratios).
- Here’s an example: A lender might tell you that in order to avoid mortgage insurance you will have to have a Loan to Value of less than 80%. This means you down payment must be 20% of the amount of the loan.

## Credit

- Credit scores and credit history are used by AZ mortgage brokers in order to estimate the risk associated with a borrower.
- While lenders like to see several open lines of credit with at least 2 years of history, others offer programs to allow borrowers to use a variety of credit histories to qualify for a loan.

## Property Types

- The type of property and how a borrower plans to use the property plays a major role in a mortgage lender’s decision on granting a loan. Home Owners Association (HOA) restrictions, government lending mortgage insurance requirements and appraisal policies can be very different from property to property. This is why your real estate agent must understand the exact details and possible restrictions before any offer is placed!

## Mortgage Programs

- There are many mortgage programs available to borrowers including allowing 100% financing, low down payments or even allowing upgrades to a property to be rolled into the mortgage loan.
- Speak with your Arizona mortgage broker about government insured programs such as FHA, USDA and VA home loans as well as conventional and jumbo loan financing.

## Pre-Approval Letters

Having a mortgage pre-approval letter in hand prior to looking for a new home is an essential first step in the home buying process.

Not only does this pre-approval letter provide the borrow with an idea of what properties they may be able to afford, this letter also gives confidence to the seller and their agent that the purchase will go though on time. However, be sure to know the difference between a “pre-approval letter” and a “Mortgage Conditions List.”

The pre-approval letter, generally issued by your Arizona mortgage broker, is provided after initial conditions are met such as income, assets and loan program conditions.

The Mortgage Approval Conditions List is a more detailed document issued by the underwriter once an entire loan package is submitted after a review of other qualifying details such as inspection issues, purchase contract updates and appraisal values.

Pre-approval letters let the borrower know the exact terms of the loan amount, down payment requirements and monthly payments. Typically this letter will include:

- Loan Amount
- Status Date and Expiration Date – most letters are good for 90 days
- Mortgage Type – Is the loan an FHA, VA, USDA, Conventional or Jumbo loan
- Term – Is the loan a 20, 30 or 40 year fixed loan, an Adjustable Rate Mortgage (ARM) with a 1, 3, 5, 7 or 10 year fixed period, or an interest only loan
- Occupancy – Is the property owner occupied, a secondary residence or an investment
- Contact Info – Lender’s name and address
- Conditions – Document and Funding requirements needed prior to final approval

## Arizona Mortgage Approval Process FAQ’s

### I was told I needed a second pre-approval letter from a different lender when I wanted to make an offer on a certain home. Why?

Some large banks that are trying to sell a bank-owned or short sale property may require this and it’s called “Cross Qualification”. In effect, this may be required in order to make the seller, the agent, or the bank who owns the property more comfortable that if the primary lending option falls through that there is a backup plan in place.

### I was pre-approved for a loan, but after I found a home and signed the contract, my lender decided to deny my loan! Why did they do that?

Unfortunately since Arizona mortgage loans have many moving parts, sometimes even the smallest change in credit scores, income or employment can change the status of a loan causing the lender to deny it at the last minute. Other issues such as the appraised value, the inspection report, or even the seller turning uncooperative can cause issues along with changes in the interest rates offered by a lender. There are many reason to go from a pre-approval to a denial, so be sure to keep in constant contact with your mortgage lender to assure things flow smoothly.

### What happens if I don’t find a home before my pre-approval letter expires?

This all depends on the mortgage program you’re involved in, but in most cases it will require you to re-submit the most recent 30 days of income and asset documentation as well as having your credit report pulled. This is precisely why it’s important to understand the expiration dates of all documents to avoid having the entire process drag out for months.

### Do I have to sell my current home before I can qualify for a new mortgage loan?

The answer is…it depends. If you’re in a financial position where you could afford BOTH payments until your first home sells, then there should be no problem! This comes down to your Debt to Income ratio (mentioned earlier) but additional expenses such as maintenance of the first property, unexpected repairs and even property taxes will need to be taken into account.
