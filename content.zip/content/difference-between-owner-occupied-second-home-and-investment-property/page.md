Original URL: https://azmortgagebrothers.com/difference-between-owner-occupied-second-home-and-investment-property/
Page Title: Owner-Occupied vs. Second Home vs. Investment Property
Meta Title: Difference Between Owner-Occupied, Second Home, and Investment Property?
Meta Description: When applying for a Arizona mortgage, a borrower's "Occupancy Type" is a major factor in the amount of down payment required, loan program available, and mortgage interest rate. Whether you are purchasing, doing a rate/term refinance or taking equity out of your property through a cash out refinance, occupancy type is always considered by the underwriter.
Canonical URL: https://azmortgagebrothers.com/difference-between-owner-occupied-second-home-and-investment-property/
H1: Difference Between Owner-Occupied, Second Home, and Investment Property?

When applying for a Arizona mortgage, a borrower’s “Occupancy Type” is a major factor in the amount of down payment required, loan program available, and mortgage interest rate. Whether you are purchasing, doing a rate/term refinance or taking equity out of your property through a cash out refinance, occupancy type is always considered by the underwriter.

Not Sure How Your Property Is Classified?

The difference between owner-occupied, second homes, and investment properties affects loans and taxes. Get expert guidance today!

Get a Free Property Classification Review

## Three Types of Residential Occupancy

### Owner Occupied / Primary Residence

According to HUD, a principal residence is a property that will be occupied by the borrower for the majority of the calendar year. At least one borrower must occupy the property and sign the security instrument and the mortgage note for the property to be considered owner-occupied.

### Second Home

To qualify as a second home, the property typically must be at least 50 miles from the primary residence, and it cannot appear that the real estate is being purchased for rental investment purposes.

### Investment Property

A property that is not occupied by the owner and is typically utilized for rental income purposes.

## Down Payment Requirements

### Owner Occupied / Primary Residence

Purchases for VA and USDA can go up to 100% financing, while FHA requires 3.5% of the purchase price as a down payment. Conventional financing may require anywhere from 5% – 25% depending on the credit score, county, property type and loan amount.

### Second Home

Average 10% down for a purchase, and 25% equity for a refinance.

### Investment Property

Down payment requirements will range from 20-25% depending on the number of units. When doing a cash-out refinance on an investment property with 2-4 units, the required loan to value will need to be 70% or lower to qualify.

*It should be noted that on any high balance loan amount the above mentioned Loan-to-Value (LTV) requirements will change. Credit score requirements also apply.

If you have any questions about this or if you have any questions you’d like us to answer on our podcast, you can submit your questions using our contact form or give us a call at(602) 535-2171. Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

•••

Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

Mortgage Brothers LLC does not provide tax, legal, or accounting advice. This material has been prepared for informational purposes only. You should consult your own tax, legal, and accounting advisors before engaging in any transaction. Mortgage Brothers NMLS 1007154, NMLS #210917 and 1618695. Equal housing lender.

Explore the key differences between an owner-occupied second home and an investment property. For further insights, check out our discussion on detached guest home appraisal issues, learn how connecting a guest house to your main home adds value, and discover the distinctions between Arizona condos and townhomes.
