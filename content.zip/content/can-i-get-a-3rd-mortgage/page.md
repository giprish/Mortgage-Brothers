Original URL: https://azmortgagebrothers.com/can-i-get-a-3rd-mortgage/
Page Title: Can You Get a Third Mortgage? Requirements & Options
Meta Title: Can I Get a 3rd Mortgage?
Meta Description: Find out why third-position residential mortgages are rarely available and how refinancing a first or second loan can unlock more equity.
Canonical URL: https://azmortgagebrothers.com/can-i-get-a-3rd-mortgage/
H1: Can I Get a 3rd Mortgage?

by

| Feb 4, 2025

We get asked this question all the time, but it’s not always in these exact words. Sometimes it’s: How many mortgages can I get on my home? or How many can you just stack? Oftentimes, it’s people simply wondering if they can get another line of credit. They’re thinking of it that way rather than as in terms of positions.

Need a Third Mortgage? Here’s What to Know

A third mortgage can be an option for accessing equity, but not everyone qualifies. Get expert advice on your best financing options.

Get a Free Mortgage Consultation

## Mortgages have positions?

Now, what’s important to understand is that every mortgage has a position. They have a first and second, and anything beyond that would continue in the same order. Technically, these are all lien positions and that’s what those numbers are standing for.

You can think of every lender basically as a standalone entity or a standalone loan. When you have a first loan on your home and you have a mortgage, that’s a standalone lender. So, if you ever need additional money, you’d be going to a totally different lender. And even if it’s the same lender, it’s going to have to be a brand-new loan.

## How many times can I do this?

That’s the question you came here for. In most cases, the answer is two, max. It’s unlikely you’ll find any bank willing to give you a third position loan or a third mortgage on your home. Even though one bank can have two different positions, if there are two, often the second one will be from a different bank than the first.

When people get a conventional loan or an FHA or VA, more often than not those are all first position liens and if you want to access more money, you’ll need to get a home equity line of credit or a fixed-rate second mortgage.

So, once you have a first and second position lien on your home, that’s really it.

## But what if I want access to more equity?

If you already had a first and second mortgage on your home and you want more equity out of your house, we would end up redoing either your first or your second mortgage. You wouldn’t go out and get a third. It all depends on whether or not you have enough equity in your home. Some banks want you to have up to 20% equity in your home when going for a second mortgage. But if you do, if you have the equity, we can create a new mortgage.

## How does what position your loan is in matter?

This part is actually pretty simple. So, when a foreclosure occurs the courts will order that your home is sold and the lien holders are paid off in the order of the lien position. The lender who’s in the first position gets their money first from the sale of your home then whatever’s left over gets paid off to the second.

During the big financial crisis in 2008, we saw a lot of second mortgages completely annihilated. In many cases, there wasn’t even enough money from the foreclosure sales to pay off the first lien.

## In Summary

The short answer is that there are no real residential third mortgages available out there, at least at any decent rate. And if there was one available, it’d be so expensive you’d never want to do it.

So, your options are basically redoing your first or redoing your second. And the only thing you have to keep an eye on is just making sure that you’re within the loan-to value caps. And as long as you’re under those loan-to value caps, you can redo your first and second as many times as you want throughout the life of your home. You just have to have the equity.

If you have any questions about this or if you have any questions you’d like us to answer on our podcast, you can submit your questions using our contact form or give us a call at(602) 535-2171. Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

•••

Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

Mortgage Brothers LLC does not provide tax, legal, or accounting advice. This material has been prepared for informational purposes only. You should consult your own tax, legal, and accounting advisors before engaging in any transaction. Mortgage Brothers NMLS 1007154, NMLS #210917 and 1618695. Equal housing lender.

Thinking about taking out a third mortgage? Enhance your knowledge by reading about spouse-related concerns, see how car loan payments affect your mortgage, understand the concept of grossing-up income, and learn about optimal mortgage closing speeds.

---

## Transcript of the Mortgage Brothers Podcast

### Can You Get a Third Mortgage? What You Need to Know

### Introduction

[00:02]Welcome to the Mortgage Brothers Podcast! I’m Eddie Knoell, and I’m Tom Knoell. Today, we’re answering a question that many homeowners ask:

👉 Can I get a third mortgage?👉 How many mortgages can I stack on my home?👉 What happens if I need more equity after getting a second mortgage?

Let’s break it all down.

### How Many Mortgages Can You Have?

[00:46]Most borrowers don’t realize that each mortgage is assigned a position on the property.

✔️ First Mortgage: Your primary home loan (conventional, FHA, VA, etc.).✔️ Second Mortgage: A home equity line of credit (HELOC) or fixed-rate second mortgage.❌ Third Mortgage? Nope! Lenders don’t typically offer third-position residential mortgages.

💡 Important: You can have multiple mortgages, but they must be in different lien positions (1st, 2nd, etc.). However, banks won’t go into third position for residential mortgages.

### Understanding Mortgage Lien Positions

[01:19]Every mortgage loan has a lien position on the property. This determines who gets paid first in case of foreclosure.

💡 Example:🏡 1st Mortgage: $250,000 (conventional loan)🏡 2nd Mortgage: $50,000 (HELOC)🏡 3rd Mortgage? ❌ Not possible (no lender offers third-position residential loans).

📌 Why does lien position matter?If you default and the home is sold, the first mortgage lender gets paid first, then the second lender, and if anything is left, it would go to the third lender (which rarely happens).

### Why Aren’t Third Mortgages Available?

[03:41]Banks don’t offer third-position mortgages because:❌ High risk – Third lenders are the last to get paid in foreclosure.❌ No demand – Most borrowers refinance instead of getting a third loan.❌ Complicated lien structure – Having three mortgages makes property sales, refinancing, and foreclosure messy.

💡 The Simple Rule: Lenders offer first and second mortgages only.

### Alternatives If You Need More Equity

[05:31]

If you already have a first and second mortgage but need more funds, here’s what you can do:

✅ Refinance Your First Mortgage – Get a new loan that includes the balance of your first and second mortgages, plus extra cash if needed.✅ Refinance Your Second Mortgage – If your second loan has a high interest rate, refinance it to a better one.✅ Increase Your HELOC Limit – Some lenders may allow you to increase your home equity line of credit (if you have enough equity).✅ Take a Personal Loan – While not secured by your home, this can provide additional funds (though at higher interest rates).

📌 Remember: You can always combine loans, but you can’t add a third mortgage.

### Why Mortgage Position Matters

[06:04]Your lien position determines who gets paid first in foreclosure:

1️⃣ First Mortgage → Always gets paid first.2️⃣ Second Mortgage (HELOC or fixed-rate second loan) → Gets paid after the first mortgage.3️⃣ Third Mortgage? ❌ Not an option for residential loans.

📌 What Happens in Foreclosure?If a home is sold due to foreclosure:✔️ The first mortgage gets paid.✔️ The second mortgage gets paid if there’s enough equity.❌ A third mortgage (if it existed) would likely get nothing—which is why lenders don’t offer them.

### What About SBA Loans or Contractor Liens?

[04:18]While third-position residential mortgages aren’t available, you can have other types of liens on your home:

🏦 SBA Loans – If you take out a business loan, the lender may place a lien on your home.🔨 Contractor Liens – If you don’t pay for renovations, a contractor can file a mechanic’s lien against your property.

📌 Key Difference: These liens aren’t residential mortgages—they are simply claims against your property for unpaid debts.

### How Much Can You Borrow Against Your Home?

[08:23]Lenders limit how much you can borrow based on your home’s value:

✔️ 80% Loan-to-Value (LTV) – Most banks require you to keep at least 20% equity in your home.✔️ 90% LTV (Rare) – Some second mortgages allow up to 90% LTV, but with higher interest rates.❌ 100% LTV (Not possible) – Banks won’t let you borrow the entire value of your home.

📌 Example:🏡 Home Value: $500,000✅ 80% LTV Limit: $400,000 (max total mortgage amount)✅ First Mortgage: $300,000✅ Second Mortgage: $50,000❌ Third Mortgage? Not possible—your total loans can’t exceed the lender’s LTV limit.

### Final Answer: Can You Get a Third Mortgage?

[07:49]🚫 No. There are no third-position residential mortgages.✔️ Your options: Refinance your first or second mortgage, or take a personal loan.📌 If you need more equity, talk to your lender about refinancing or increasing your HELOC.

### Need Help? Contact Us Today!

[10:28]If you’re wondering how to access more home equity, we’re here to help!

📞 Contact us: Contact Form📞 Call us for a personalized mortgage review

📺 Like & Subscribe for More Mortgage Tips!If you found this information helpful, subscribe to our channel and hit the notification bell for expert insights.

💡 Final Thought: If you need more equity, explore refinancing options—but don’t expect to find a third mortgage! 🚀
