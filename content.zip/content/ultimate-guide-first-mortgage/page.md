Original URL: https://azmortgagebrothers.com/ultimate-guide-first-mortgage/
Page Title: Ultimate Guide: Pro Tips to Secure Your First Mortgage
Meta Title: The Ultimate Guide to Your First Mortgage
Meta Description: The Phoenix Valley was recently voted out of the top 20 markets for first time buyers, highlighting a fact that most first time buyers have probably already noticed on their own: it's getting more expensive to buy your first home. But don't despair. You can still buy the home of your dreams, even if it
Canonical URL: https://azmortgagebrothers.com/ultimate-guide-first-mortgage/
H1: The Ultimate Guide to Your First Mortgage

# The Ultimate Guide to Your First Mortgage

The Phoenix Valley was recently voted out of the top 20 markets for first time buyers, highlighting a fact that most first time buyers have probably already noticed on their own: it’s getting more expensive to buy your first home.

But don’t despair. You can still buy the home of your dreams, even if it will take more time and planning than might have been needed even just a year or two ago. In this guide, I’m going to give you all the insider tips on how you can get into your first home without paying too much.

Start Your Journey to Secure Your First Mortgage Now!

Begin your path with expert guidance. Connect with our professionals for personalized advice on securing your first mortgage.

Get Started Today

## The Basics: What Do Lenders Look For?

So, what do you need to do to prepare to buy your first home? What do lenders want to see before approving you for a mortgage? Here are some of the things lenders will consider:

- Good CreditLenders want to know if the loans they provide will be repaid on time. The best way they have to determine this is by looking at what a loan applicant has done in the past. Most lenders look at credit scores and credit history to determine whether you have a history of paying your bills on time.
- Reliable IncomeLenders also want to know whether you have a means of repaying them. Do you have the income to cover the mortgage? They want to see evidence that you have a job that pays enough to cover a mortgage, and they want some evidence that you’re likely to hold that job for a while. Typically they’ll be looking for 2 years with the same employer, give or take. If you can’t show 2 years with a single employer, 2 years at a rising or similar income level can also work.
- Debt to IncomeYour debt to income ratio is another aspect of your financial health that lenders look at when considering you for a loan. How much of your income is currently being used to pay outstanding debt? If the ratio is too high, that’s an indication that you might have trouble paying off your loan.
- Assets and LiabilitiesLenders have learned that sometimes people who have good credit and reliable income at the time a loan was made can experience a change in their circumstances, such as job loss or a long-term illness – that will result in their not being able to pay a mortgage. Unfortunately, even when these things happen, mortgages still have to be paid, so lenders want to know if you have assets that you could use in a pinch. They also want to know how many other liabilities you have – such as credit card debt, student loans or auto payments – that might also have to be paid.

## How Do Lenders Look at Credit?

Many people have the idea that lenders just look at a credit score to determine if a buyer has good credit. There’s actually quite a bit more to it. So, what do lenders look at when it comes to credit?

1. Credit scoreYes, most lenders do look at your credit score and this is an important consideration when it comes to getting a loan. Generally speaking, you’re considered to have good credit when your score is around 700 or above. This will usually qualify you for the best mortgage rates. A score as low as 620 may still be considered, but the lower the score, the higher the rate. Below a 620 credit score will usually not be considered.
2. Credit utilizationAnother aspect of your credit that lenders will look at, is how much of your current available credit you are using. How high are your balances? If the limit of your credit card is $25,000, is your balance hovering around that amount, or are you following responsible credit practices and paying that off? The less you owe on those cards, the lower your utilization rate and that is what lenders want to see.
3. Credit historySome lenders don’t just look at credit score. They look at your whole credit history. This is a benefit to buyers who are just getting financially established because they often don’t have a long credit history and this can lower their scores, even though their actual credit history is good. VA lenders often consider the buyer’s history of on-time payments for this reason.

## Down Payments: How Much Do I Need to Save?

When prices are rising quickly, first time buyers often become concerned that they will be priced out of the market, because they aren’t able to save enough to keep up with the increase in down payments that may be required as homes become more expensive.

The down payment amount you need varies depending on the price range of the home and the type of loan you are getting. Conventional loans usually require 20% down, but there are also many conventional loans that have down payments as low as 5%. For veterans, VA loans are available at 0% down. FHA loans require a 3.5% down payment.

Of course, the downside to a low down payment is that you have a higher principal balance and thus, your payments will be higher. In general, the more you can put toward your down payment, the better off you will be: you’ll owe less overall, have lower payments and be able to pay off your loan more quickly.

## How do Lenders Look at Income?

Some people think you need to have a lot of money to get a mortgage, but this isn’t the case. You only need an income big enough for the mortgage you’re trying to get.

Lenders look at several things when it comes to your income. At a basic level, they want to determine if you have income sufficient to pay your mortgage. How much is enough, though? Most lenders want to see no more than a third of your monthly income going towards covering your housing related expenses. Lenders define these expenses as including principle, interest, taxes and insurance, or PITI.

Just remember: income requirements vary by the size of the loan; as a general rule your PITI should not exceed a third of your monthly income.

Discover Your Borrower Rating Today!

Take our quick quiz to assess your credit profile and receive personalized insights to guide your mortgage journey.

## Finding a Lender

Now that you know some of the basics around getting a loan, let’s look at the process. One of the first decisions you need to make is to find a lender you trust to get you the best mortgage that is right for you.

Once, this simply involved going down your local bank and talking to their lending officer. Today, you have a lot more options. These options include:

- Online lendersIf you’re looking online you’ve probably noticed a lot of online lenders offering really low rates for loans. There are a few things you should know. The rates offered online are teaser rates – the lowest possible rates that could ever be offered to a buyer that has perfect credit, no outstanding debt, and plenty of cash to pay down points. The rates that will actually be available to you will likely not match those seen online. It’s also challenging for a first time buyer to work with an online lender because they are processing huge volumes of loans, leaving them too busy to be available to answer questions. Follow up tends to be poor as well, so your loan closing can be subject to problems and delays.These issues can cost you big. If your seller won’t wait for your lender to resolve issues, you can lose your earnest money deposit or even the house you wanted to buy. It’s better to develop a relationship with a lender you trust in your local market.
- Mortgage brokersA mortgage broker is a person who originates or takes applications for loans that are available on the open market. Those loans are available from multiple lenders, which means a broker has access to a wide variety of loan programs and types. Unlike a bank that will only sell you the loans that they offer, a broker can give you access to just about any loan available on the market and that means they can help you get the best rate possible.
- Mortgage bankersA mortgage banker is similar to a broker in that they originate loans that will be provided by other lenders. They also often have some of their own “in-house” loan programs that they can offer. If your credit is challenged, sometimes a mortgage banker will have in-house programs that they service – called portfolio loans – that you may be able to qualify for.
- Banks and credit unionsBanks and credit unions provide home loans too. These loans are limited to those actually provided by the bank, which means there’s not much selection. This often equates to a higher rate.

## What Types of Loans Are There?

The most common loan types are conventional loans, VA and FHA loans. Here is a little more information about each of them.

- VA loans are for veterans of the armed forces. VA loans are loans that are guaranteed by the Veterans Administration, which protects the lenders providing these loans against default. Because they’re federally guaranteed, these loans offer very low rates, and also can be obtained for as little as 0% down. If you’re a first time buyer who is also a veteran, ask if you qualify for a VA loan.
- FHA loans are another loan program which is commonly used by first time buyers. FHA loans are federally guaranteed loans that are often used by first-time buyers. They offer low rates and a down payment of just 3.5%,
- Conventional loans are loans with are bought and sold on the open mortgage market (more about that in a moment). These loans are offered by all types of lenders according to criteria that makes them easy to underwrite.

## Conventional Loans and The Mortgage Market

The mortgage world is pretty complex with a lot of players. Many buyers think that the loan they get, whether it’s from a broker or a bank, is actually made by the person they got it from and will be repaid to them. This is sometimes true with portfolio lending, but more often than not, loans are made and then resold on the conventional loan market.

This market is overseen by an organization called Fannie Mae(stands for FNMA, or Federal National Mortgage Association), which sets underwriting standards that conventional loans have to adhere to. They’re the ones who determine the down payment amount that must be provided (usually 20%), the documentation that must be provided, etc., for each individual loan.

Conventional loans underwritten to Fannie Mae standards are loans that are easy to sell on the mortgage market after closing because they have a high probability of being repaid on time. After selling a loan on the open market, your lender will have funds available to make more loans. After being sold, loans are assigned to a servicer who will actually process payments.

## Getting Pre-Approved

After selecting a lender, your next step is to get pre-approved. A pre-approval is when the lender gathers all the information needed to determine how much you qualify for and actually verifies that the number are accurate.

For a pre-approval, you need to provide quite a bit of financial information, including:

- Authorization to pull credit.
- Social security number – you provide this and your current residence on an application.
- Proof of employment and proof of income – this is usually your most recent pay stubs.
- Tax Information – Usually, the last two years. Proves ongoing income and stable employment.
- Bank Accounts and Balances – Lenders want to know what assets you already have and whether you have cash to close.

With this information, a lender can determine the actual loan amount you can be approved to receive and whether you will, in fact, be able to obtain that loan.

It’s important here to distinguish that there is a different between a pre-approval and a pre-qualification. Often, when first time buyers are looking for a home, they want to determine if they can afford the home. A lender may take some basic information over the phone and come back to them with a number. Unless you’ve actually provided the detail to back up what was discussed over the phone, this isn’t a pre-approval, it’s a pre-qualification.

## Next Step: Finding a Home

You should provide your pre-approval information to your real estate agent as soon as you are ready to start looking. They can use this to help you get the home you want. It’s a hot market right now in the Phoenix Valley, so that means homes are selling quickly. You and your agent should be ready to submit offers quickly, and that means it’s critical to have a solid pre-approval – NOT a pre-qualification. Your pre-approval also helps your agent determine the right price range for you.

Depending on down payment and your personal comfort level, your price range could be lower or higher than your pre-approval amount. You and your agent need to communicate clearly about this. The most important reason to have your pre-approval in hand before you start looking is that it saves time and keeps finances from complicating your decision-making. You’ll know whether you can afford the house you want and what the payments will be before you start looking.

## Making the Offer and Making a Loan Application

Making an offer to buy your first home is exciting. Many buyers also find it very nerve-wracking. The best way to stay calm during the process is to be educated about the process beforehand.

You and your agent will write up the offer on the home you want and submit it to the seller. The offer will entail making a lot of decisions quickly about inspections, earnest money deposits and more, so it’s good to work out a strategy beforehand with your agent.

An updated pre-approval letter should be sent along with the offer to make sure your seller knows that you are ready and able to buy the house. Usually, you will also submit an earnest money deposit that serves as an assurance to the seller that you intend to make good on the offer. The earnest money is not kept by the seller; it goes to escrow where it will be put toward your down payment and closing costs.

After the offer is negotiated (this usually takes a couple of days) and accepted, you will need to work quickly to get a formal loan application filled out. The time limit will be spelled out in your purchase and sale agreement; usually the timeframe is 5 days, but the sooner application is made, the sooner we can start processing your loan.

## What does it mean to lock my rate?

When you were first getting pre-approved for your loan, your lender may have quoted you a rate that was based on what that rate was that day, but until you make formal application and lock your rate, you won’t know your actual rate. This is because rates actually change on a daily basis depending on what is happening in the financial markets.

Locking rates can be stressful because rates can go up or down from the day you lock them. If they go up, you’ll save money because you’ll have gotten a lower rate than what might be available in the future. If they down, you miss out on the opportunity to get that lower rate.

Your mortgage lender can advise you about the best time to lock rates. If rates are very low, and starting to trend higher, your risk of missing out on a future dip in rates is outweighed by the likelihood that rates will go up, so locking in quickly is the best choice. If the trend is downward, you might be better off to “float” as long as you can. When it comes to “lock or float,” your own personal outlook and comfort with risk is likely to be the determining factor.

## The Lending Process

Once you’ve made formal application and locked a rate, the lender will process the loan. To avoid delays or even the possibility that your loan application will be denied, make sure to:

1. Follow all the terms of your purchase and sale contract.Make sure you fully understand what actions you’re required to take by what dates in order to meet the terms of your contract. Your agent can help with this – many of them provide a calendar of crucial dates for applications, inspections, responses and waivers.
2. Provide all loan materials requested in a timely way.If your mortgage lender asks for a piece of additional information, make sure you respond quickly. Your loan likely cannot be processed and approved without it.
3. Refrain from making any large purchases on credit.DO NOT purchase a car, a boat, a fabulous vacation, or do an expensive renovation of your current home that you plan to sell using a home equity line, credit card or any other form of credit. This will show up on your credit report and can slow or stop your approval. It can wait.

## Final Approval and the Closing Table

Final Approval for your loan usually comes in about a week before closing but there can often be delays in this process. Sometimes these delays are due to a backup at the lender if a lot of other loans need to be processed first. When lending volumes are high, lenders “triage” their approvals and handle the most urgent cases first. Delays can also be caused by issues on the buyer end – such as buying that boat we cautioned you against, which causes the lender to have to re-process your file.

Stay in close contact with your lender and your agent as closing approaches to make sure everyone has what they need. A few common to-dos for you around closing time include:

- Final inspection of the home 3 – 5 days in advance of closing. The seller’s belongings should be out, or on the way out, by this time. If not, you’ll want to find out why.
- Setting an appointment with your closing attorney or escrow agent to sign all final paperwork.
- Key transfer – agents will often handle this for you.
- Move-in – It’s best to delay your move in until a day or two after closing. This gives time to have the house cleaned before you move in. Unlike a rental, sellers are not required to clean carpets or paint before you move in, so if this is important you’ll need to allow time after closing to get it done.

## Celebrate – You’re a Homeowner!

After several months of looking for a home and a flurry of activity to close on your home, the house will close and you’ll move in. Maybe you’ll begin making those improvements that will really make the home your own. Just remember, even though the loan process can be stressful, in the end it’s all worth it to become a homeowner. Make sure to take time to celebrate this next step in your life!

Step Into Homeownership in Arizona Today!

Unlock expert tips and essential insights that empower you as a first-time homebuyer. Let our specialists help you make the leap with confidence.
