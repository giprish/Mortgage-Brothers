Original URL: https://azmortgagebrothers.com/buying-down-your-arizona-interest-rate/
Page Title: Buying Down Your Home Loan Interest Rate: Is It Worth It?
Meta Title: Buying Down Your Home Loan Interest Rate
Meta Description: Learn how mortgage buydowns and discount points work in Arizona, including simple, 2-1, and 3-2-1 options that can lower your rate.
Canonical URL: https://azmortgagebrothers.com/buying-down-your-arizona-interest-rate/
H1: Buying Down Your Home Loan Interest Rate

by

| Feb 4, 2025

If you have not heard the term buy down before, it means that you can pay a one time fee to get a lower Arizona mortgage rate at the time you take out your Arizona loan. Your lender or your Arizona mortgage broker can explain what it would cost you to buy down your Arizona mortgage rate.

To receive a buydown, the lender will charge you a discount point. The discount point may vary, but it is important to know what a point is. One point is equal to 1% of your loan. So, if you are obtaining a $200,000 mortgage, 1 point is $2,000. A 1 point buy down will typically lower your interest rate by .25%. An Arizona mortgage lender or broker can provide you with a mortgage rate sheet so you can determine what your rate would be.

Want to Lower Your Mortgage Interest Rate?

Buying down your rate can save you thousands over time. Let us help you decide if it’s the right move for your mortgage.

Get a Free Rate Analysis

## Types of Mortgage Buydowns

### Simple Mortgage Buydown

- Borrower pays a discount point to lower their Interest rate for the entire life of the loan.
- Applicable for all Conventional, FHA, VA, and USDA loans

### 3-2-1 Mortgage Buydown

- 30-year fully amortized loan
- Interest rate increases at 1% every year for the first three years of the loan
- Fixed rate for the remaining loan term

### 2-1 Buydown Mortgage

- 30-year fully amortized mortgage
- interest rate increases at 1% every year for the first two years of the loan
- Fixed rate for the remaining loan term

It is best to calculate your payments if you pay no buy down points and compare it to your payment with buy down points. If the savings is not sufficient enough for you then it doesn’t make sense. You may be able to get the seller to pay your buy down points.

Check with your lender first to make sure they will allow it and then you can negotiate that in your contract if the seller is willing to pay them. The buy down points are tax deductible in the year you pay them and close your loan even if the seller pays them for you. The next best strategy is to keep the higher rate with no points.

If you have any questions about this or if you have any questions you’d like us to answer on our podcast, you can submit your questions using our contact form or give us a call at(602) 535-2171. Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

•••

Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

Mortgage Brothers LLC does not provide tax, legal, or accounting advice. This material has been prepared for informational purposes only. You should consult your own tax, legal, and accounting advisors before engaging in any transaction. Mortgage Brothers NMLS 1007154, NMLS #210917 and 1618695. Equal housing lender.

Discover effective strategies for buying down your Arizona interest rate. For a comprehensive view, explore our discussion on inspection notices, learn about the prequalification form, understand mortgage rates & interest deductions, review prepayment penalties, and consider second mortgage options as well as the latest on capital gains.
