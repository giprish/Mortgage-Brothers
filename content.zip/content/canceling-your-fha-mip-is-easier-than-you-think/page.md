Original URL: https://azmortgagebrothers.com/canceling-your-fha-mip-is-easier-than-you-think/
Page Title: Canceling FHA MIP Is Easier Than You Think
Meta Title: Canceling your FHA MIP is Easier than you think
Meta Description: If you are still paying Mortgage Insurance Premiums (MIP) on a Federal Housing Administration (FHA) backed loan you may be paying more than you need to. Canceling this type of mortgage insurance can also be easier than many homeowners believe. Many homeowners were forced into a FHA backed mortgage and its resulting MIP when the
Canonical URL: https://azmortgagebrothers.com/canceling-your-fha-mip-is-easier-than-you-think/
H1: Canceling your FHA MIP is Easier than you think

If you are still paying Mortgage Insurance Premiums (MIP) on a Federal Housing Administration (FHA) backed loan you may be paying more than you need to. Canceling this type of mortgage insurance can also be easier than many homeowners believe. Many homeowners were forced into a FHA backed mortgage and its resulting MIP when the housing market dipped. Yet now with house values on the rise, you may be in a position to get rid of this unnecessary insurance payment. Find out how below.

Ready to Cancel Your FHA MIP?

Canceling FHA MIP can lower your monthly payments and save you money. Find out if you’re eligible and how to get started today.

Get FHA MIP Cancellation Help

## MIPs at a Glance

Mortgage insurance is a way for the federal government to backstop banks and ensure a healthy banking system. One way to do that is to insure these mortgages through the FHA, a housing mortgage insurer. Borrowers, or banks, can use these products to secure their mortgages against loss if a consumer or homeowner defaults. This was especially important when the housing market fell and housing prices crashed. Homeowners were walking away from homes that devalued by as much as 20-50% and the banks were left with the mortgage. In this case, the bank could get paid back by the mortgage insurance.

Now that housing values are on the rise again, these products are not as needed as they once were. As a homeowner, you may have a significant amount of equity in your home and no longer fear a housing market dip. If this is you, getting rid of or canceling your insurance premiums can save you hundreds or thousands of dollars depending on the value of your home.

## Annual FHA Insurance Premiums

This type of MIP is paid in 12 monthly installments annually, hence the name. All FHA mortgages require this type of insurance and appear on your mortgage statement monthly as Monthly Mortgage Insurance, Risk based HUD or HUD Escrow. It is not usually shown as an MIP premium. These premiums change frequently, although not usually every year. However during the market uncertainty between 2008 and 2013, they changed 8 times.

The last market change was in 2015 when the annual MIP dropped from the previous 1.35% to 0.85% annual premium. The premium has ranged from 0.5% to 1.35% during this period. Depending on when you took out your mortgage you may be paying the maximum premium on your mortgage and now is a good time to get out of it.

## FHA Mortgage Insurance Reductions

For those homeowners that have had their FHA mortgage since before 2009, there is a good chance you can do a Streamline FHA refinance and reduce your mortgage Insurance. This is because long time FHA customers were “grandfathered” into certain rate exemptions a few years ago. Your rates are as follows under these exemptions:

- Upfront Mortgage Premium drops from 1.75% to just 0.01% per $10,000. $100,000 mortgage would be 0.1%
- Annual MIP rates can drop by as much as 1% to just 0.55%

These rates are the same on 15 or 30 year loans and are the same no matter the Loan-To-Value calculation. Simply refinance your mortgage within the FHA to these rates.

## Wait it out?

However, if your mortgage is after June 1st, 2009, you will not qualify for these exceptional rates. Most FHA MIPs cancel out under certain LTV situations such as these:

- If you have paid a mortgage for at least 60 months, it is a 30 year mortgage and your LTV has reached 78%,
- If you have a 15 year mortgage and your LTV has reached 78%.

In either of these situations your MIP payments should cease. The LTV values on these mortgages should reach the 78% within 11 years for a 30 year and only 2 years for a 15 year mortgage.

So if you have a 15 year mortgage from 2013, within a few months your LTV value should reach 78% and your MIP should self-cancel. However, if you have a 30 year mortgage or have a 15 year mortgage from after 2013, you still have an ability to get away from these onerous MIP payments.

## Refinance to reduce or eliminate your mortgage insurance

Many homeowners have seen their home value rise significantly within the last 6 months to a year. This rise in value is a great opportunity for those that are not eligible for an exception or have a mortgage started after 2013. You are NOT locked into these products forever to pay the MIP premium.

Using a conventional home loan, you can simply refinance your way out of your mortgage insurance premiums. As long as you have 5% equity in your home you can transition to Fannie Mae or Freddie Mac for Mortgage Insurance rates that are much more attractive. Furthermore if you have 20% equity in your home, your mortgage insurance payments automatically cancel with a conventional mortgage.

Find out if you qualify for a FHA exception, can wait out a few months to drop the MIP payments or should you refinance away from the FHA to Fannie Mae or Freddie Mac.

Learn why canceling your FHA MIP might be simpler than you expect, and discover the steps to save on your mortgage. For a broader perspective, check out when a mortgage payment is considered late, learn how to calculate PMI, and study an amortization chart. Also, explore mortgage trigger leads, see how APR works, review closing costs, understand why mortgage payoff can exceed the balance, and learn if a past late payment affects your approval
