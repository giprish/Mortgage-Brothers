Original URL: https://azmortgagebrothers.com/glossary/
Page Title: Master Mortgage Glossary: Understand Key Terms
Meta Title: Master Mortgage Glossary: Understand Key Terms
Meta Description: Explore our Mortgage Glossary for clear definitions of essential mortgage terms and expert insights from Arizona Mortgage Brothers.
Canonical URL: https://azmortgagebrothers.com/glossary/
H1: Glossary Terms

# Glossary Terms

Adjustable-rate mortgage (ARM): A mortgage with an interest rate that can change periodically, based on a specific financial index.

Amortization: The process of paying off a debt, such as a mortgage, through regular payments.

Appraisal: An estimate of the value of a property, typically conducted by a licensed appraiser.

APR (Annual Percentage Rate): The annual cost of a loan, including interest, fees, and other charges, expressed as a percentage.

You’ve Mastered the Mortgage Glossary—Now Connect with Experts!

Leverage your new knowledge from our Mortgage Glossary and contact Arizona Mortgage Brothers for personalized mortgage guidance. https://azmortgagebrothers.com/if-i-have-1-mortgage-late-in-the-past-12-months-can-i-get-approved-for-a-mortgage/#Get-in-Touch

Get Expert Help

Balloon mortgage: A mortgage with a large final payment, due at the end of a short term, which is typically five or seven years.

Bridge loan: A short-term loan used to bridge the gap between the purchase of a new property and the sale of an existing one.

Cash-out refinance: A refinance in which the borrower takes out a larger loan than the current outstanding balance, and uses the difference for other purposes.

Closing costs: The expenses associated with the purchase or refinance of a property, such as appraisal fees, title insurance, and attorney’s fees.

Conventional mortgage: A mortgage that is not backed by the government and typically requires a higher down payment and credit score.

Credit report: A document that provides detailed information on a borrower’s credit history, including payment history, outstanding debts, and credit scores.

Down payment: The amount of money paid upfront by the borrower towards the purchase of a property.

Equity: The difference between the value of a property and the amount still owing on the mortgage.

FHA loan: A mortgage that is insured by the Federal Housing Administration (FHA) and typically requires a lower down payment and credit score.

Fixed-rate mortgage: A mortgage with an interest rate that remains the same for the entire term of the loan.

Foreclosure: The process of selling a property to pay off an outstanding mortgage when the borrower is unable to make payments.

Home inspection: A professional evaluation of the condition of a property, typically conducted prior to purchase.

Interest: The cost of borrowing money, typically expressed as a percentage of the loan amount.

Interest-only mortgage: A mortgage in which the borrower only pays the interest on the loan for a certain period of time, before beginning to pay off the principal.

Jumbo loan: A mortgage that exceeds the conforming loan limit, typically set by the Federal Housing Finance Agency (FHFA).

Lien: A legal claim on a property, used to secure payment of a debt.

Mortgage broker: A mortgage broker is a professional who acts as an intermediary between borrowers and lenders. They work with a variety of lenders to find loans for their client.

Mortgage insurance: Insurance that protects the lender in case the borrower defaults on the loan.

Mortgage-backed security (MBS): A financial security that is backed by a pool of mortgages. These securities are issued and sold by government-sponsored enterprises such as Fannie Mae and Freddie Mac, or by private institutions.

Negative amortization: A situation where the unpaid interest is added to the loan balance, resulting in the borrower owing more than the original loan amount.

Points: A percentage of the loan amount, charged by the lender as a fee for originating the loan. Each point is equal to 1% of the loan amount.

Pre-approval: A process where a lender pre-qualifies a borrower for a mortgage loan, based on their credit score and income.

Prepayment penalty: A fee charged by the lender if the borrower pays off the loan early.

Principal: The amount of money borrowed, not including interest.

Private mortgage insurance (PMI): Insurance that protects the lender in case the borrower defaults on the loan, typically required for loans with less than 20% down payment.

Refinance: The process of obtaining a new mortgage to pay off an existing one.

Refinancing: The process of obtaining a new mortgage to pay off an existing one, typically to secure a lower interest rate or change the loan terms.

Reverse mortgage: A type of loan that allows homeowners 62 and older to borrow against the equity in their home, with no repayment required until the borrower sells the home or dies.

Securitization: The process of pooling mortgages together and selling them as securities to investors.

Subprime mortgage: A type of mortgage that is offered to borrowers with poor credit, typically at a higher interest rate than prime mortgages.

Title insurance: Insurance that protects the borrower and lender against any defects in the title of a property.

Title: A legal document that establishes ownership of a property.

Underwriting: The process of evaluating a loan application, including the borrower’s creditworthiness and the property’s value and condition, to determine if the loan should be approved.

Variable-rate mortgage: A mortgage with an interest rate that can fluctuate over time, based on market conditions.
