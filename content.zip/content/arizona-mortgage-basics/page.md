Original URL: https://azmortgagebrothers.com/arizona-mortgage-basics/
Page Title: Arizona Mortgage Basics: Start Your Journey
Meta Title: Arizona Mortgage Basics
Meta Description: What exactly is a mortgage anyway? In simple terms a mortgage is a loan that is secured or backed by real property. It is then paid back over a set period of time. The term “secured” means that the lender is protected by the piece of property that he can take ownership of in the
Canonical URL: https://azmortgagebrothers.com/arizona-mortgage-basics/
H1: Arizona Mortgage Basics

# Arizona Mortgage Basics

What exactly is a mortgage anyway? In simple terms a mortgage is a loan that is secured or backed by real property. It is then paid back over a set period of time. The term “secured” means that the lender is protected by the piece of property that he can take ownership of in the event that the borrow defaults on the loan and decides not to, or is unable to, repay the debt. If a borrower does not pay, the lender takes the property back to offset their losses.

Start Your Mortgage Journey Today!

Contact Arizona Mortgage Brothers for personalized advice on Arizona Mortgage Basics and take your first step toward homeownership.

Get Started

No matter where you live or who does your loan, there are a few standard components to any Mortgage Loan that we will cover below:

## Mortgage Approval

Just like any loan, you need lender approval. In order to be approved there are always a pre determined set of guidelines. Each lender’s guidelines may vary slightly in order to determine if you are approved for a loan, but generally speaking an Arizona mortgage broker will look at your credit history, employment history, your income and any assets and debts you may have. The property must also meet certain standards set by the mortgage lenders before a borrower can obtain a mortgage loan backed by real estate.

Additionally, the property must also meet certain standards set by AZ mortgage lenders before a borrower can obtain an Arizona mortgage loan back by real estate.

## Mortgage Payments

Home loans will normally be set for periods of 15 or 30 year fixed mortgages. Each payment will include both a principal portion and an interest portion. The principal portion goes toward paying down the initial amount borrowed while the interest all depends on the loan rates offered by the lender. Typically, the amount of interest paid per month will decrease and the amount towards principal will increase. This is referred to as “amortization”. Your mortgage lender can also offer other payment plans for your mortgage such as interest only for a period of years or an introductory teaser rate at the beginning of a loan. They can help you understand these other options and any long term impacts or issues that may come along with them.

## Mortgage Programs

Your Arizona mortgage lender has many mortgage program options available and can explain them in detail so that you can make an informed decision as to which plan is best for you. You may also be eligible for federally insured programs such as FHA or VA loans, which have more flexible qualifying guidelines. Be sure to exhaust all options.

## Closing Costs/Fees

The cost of obtaining a mortgage loan depends on whether you are paying “points” to obtain a lower mortgage rate. Some loans may have additional loan processing fees or underwriting fees due to the work that is involved in the transaction. Costs can be confusing, but remember that there are several consumer protection policies implemented by the government that will help buyers understand their options during this process. There are also other out of pocket expenses, such as appraisal fees, pre-paid property taxes, insurance and interest, HOA dues, and inspections that are not associated with the mortgage itself but that buyers will have to be aware of.

## Mortgage Rates

Phoenix home loan rates can change several times per day, but there are a few market factors that you can always pay attention to that may impact your monthly mortgage loan payment. Watch and learn. Shop around for the best rates and learn the difference between the note rate and the APR. Arm yourself with all the right information before you begin the process of purchasing your home. See The Mortgage Brothers Team with any and all questions you may have regarding your home purchase and lending process. We are here to help make it easy and effortless for you to purchase your home.
