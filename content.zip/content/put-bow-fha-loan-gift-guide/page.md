Original URL: https://azmortgagebrothers.com/put-bow-fha-loan-gift-guide/
Page Title: Put a Bow On It: Your Complete FHA Loan Gift Guide
Meta Title: Put A Bow On It: FHA Loan Gift Guide
Meta Description: Learn FHA gift fund rules for down payments—gift letters, documented transfers, acceptable donors, and why cash gifts are not allowed.
Canonical URL: https://azmortgagebrothers.com/put-bow-fha-loan-gift-guide/
H1: Put A Bow On It: FHA Loan Gift Guide

Many first-time homebuyers do not have the savings on hand for a large down-payment on their mortgage. This is why they often choose an FHA loan over a Conventional loan. Not only does an FHA loan only require 3.5% down on the loan, but it also allows for gifts to be accepted in order to help fund the purchase. A gift, in this case, refers to any funds the borrower receives from a private donor that do not have to be repaid. For example, parents giving their child money to put toward the downpayment counts as a gift.

First-time homebuyers and borrowers, who are often unfamiliar with the mortgage loan process, do not understand how intricate the process of applying for and being approved for a mortgage is. During the approval process, the borrower’s finances will need to be thoroughly documented and reviewed, and all money will need to be accounted for. Though FHA loans allow for gifts, there are still rules and regulations regarding accepting and using gifts for an FHA loan.

Need Help with Your FHA Loan Down Payment?

Gift funds can make buying a home easier. Learn how to use them for your FHA loan and get started today.

Get FHA Loan Guidance

Here are some of the most common things to remembering when considering a gift for your FHA loan.

## FHA Loan Gift Basics

### Gifts Can’t Be In The Form Of Cash

Cash gifts are not acceptable sources of gift funds from donors. The reason being that the lender has to be able to document the origins of the gift funds.

### Gift Fund Deposits Must Be Documented

If the homebuyer has deposited the gift funds into their bank account, the lender will want to source the funds by documenting the transfer from the donor’s bank account into the buyer’s account.

### The Lender Will Require a Gift Letter

To verify where the funds came from and to document that the funds are a non-repayable gift, the lender will require a signed gift letter from the donor. This letter will outline the exact dollar amount of the gift, declare that no repayment is required, and feature the donor’s relationship to the homebuyer, name, address, and phone number.

### If The Gift Is Borrowed, Additional Documentation Is Required

If the gift donor has borrowed the funds, documentation from the bank or savings account is required by the lender. If the donor can’t document the funds, because, for example, they are borrowed from a third party or from a line of credit, the donor must provide written evidence that the gift funds came from an acceptable source.

### Funds Must Come From An Approved Source

All of the homebuyer’s money must be verified to come from approved and acceptable sources by the lender. These sources include the borrower’s own savings accounts and cash reserves, cash-in investments and savings bonds, and other holdings.

### Funds Can’t Be Non Collateralized

Funds used for an FHA loan are considered non collateralized and not approved sources if they come from sources such as payday loans and credit card cash advances. Funds are also not approved if they come from an individual donor who requires repayment of the funds.

### Acceptable gift donors include

The homebuyer’s relatives, employer, governmental agency or public entity (that has a program for home ownership assistance), labor union, close friend (with a clearly documented and defined interest in the buyer), and a charitable organization.

Have Additional Questions? Let Us Help With Answers!

Contact Us Today at 602-535-2171

Or reach us using our contact form

Or Complete our Inquiry Form

Get the details on FHA loan gift options with our comprehensive guide. For additional context, consider our discussion on seller concessions, check out the personal property guide, and discover tips on skipping two mortgage payments.
