Original URL: https://azmortgagebrothers.com/how-to-skip-2-payments-on-your-mortgage/
Page Title: How to Skip Two Payments On Your Mortgage?
Meta Title: How to Skip 2 Payments On Your Mortgage?
Meta Description: See how refinancing can let you skip two mortgage payments, why interest is prepaid or rolled forward, and why it does not save money.
Canonical URL: https://azmortgagebrothers.com/how-to-skip-2-payments-on-your-mortgage/
H1: How to Skip 2 Payments On Your Mortgage?

Did you know it’s possible to skip 2 payments on your mortgage? Well, we’re going to dig into just how you can do that.

Need Financial Flexibility on Your Mortgage?

Skipping two mortgage payments could help ease financial stress. Find out if you qualify and how to get started.

Get a Free Mortgage Consultation

## A few things you should know

Mortgage payments are paid on the first of every month.

Mortgage payments are paid in arrears, meaning that when you make a payment on the first of the month you are, in fact, paying for the previous month.

## So, how does skip 2 payments on your mortgage work?

In short, there is no payment the month you close and no payment on the final month of a mortgage when refinancing. So, if you close on November 10th, you’re not making the December payment. In this case, you’re basically rolling the interest into a payoff. It’s not free, but rather you’re squishing it into either the new or old loan. See, when you close the loan on November 10th you prepaid that interest in November, and then the December payment would end up being due on January 1st because it is paid in arrears.

## Is this a way to save money?

It’s not, unfortunately. Sometimes people will call us and be like, I heard that it’s never good to close at the beginning of the month, you just spend way too much money doing it that way. Well, s dince that’s not really the case the way we explain it is by saying it’s kind of like a balloon. It stays the same size, but we are either squishing it into the old loan or squishing it into the new loan. It’s a different shape but the volume remains the same. You’re either prepaying it or delaying it, there’s no cheating the system.

If you have any questions about this or if you have any questions you’d like us to answer on our podcast, you can submit your questions using our contact form or give us a call at(602) 535-2171. Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

•••

Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

Mortgage Brothers LLC does not provide tax, legal, or accounting advice. This material has been prepared for informational purposes only. You should consult your own tax, legal, and accounting advisors before engaging in any transaction. Mortgage Brothers NMLS 1007154, NMLS #210917 and 1618695. Equal housing lender.

Explore smart strategies to skip two payments on your mortgage and ease your cash flow. To round out your financial planning, read about seller concessions, watch our personal property guide, and learn more in our FHA loan gift guide.

---

## Transcript of the Mortgage Brothers Podcast

### How to Skip Two Mortgage Payments When Refinancing

(00:02) 🎙 Welcome to the Mortgage Brothers Podcast! I’m Eddie Knoell, and I’m Tom Knoell. Today, we’re answering a very common question from borrowers:

👉 “Hey Eddie, hey Tom, how do I skip two mortgage payments? I heard that when I refinance, I get to skip payments. How does that work?”

📌 Let’s break it down. Is skipping mortgage payments really possible, or is it just a misconception?

### Mortgage Payments: How Do They Work?

(00:36) 💡 First, let’s clarify how mortgage payments work.

1️⃣ Mortgage payments are always due on the first of the month—every lender follows this rule.
2️⃣ You pay for the previous month’s interest—unlike rent, which is paid in advance.
3️⃣ Skipping payments doesn’t mean free money—it’s all about how interest is calculated and rolled into your new loan.

🚨 You can’t just move your payment to another day—the first of the month is standard across all lenders.

### Skipping One Payment When Buying a Home

(01:13) If you’re purchasing a home, you’ll always skip one mortgage payment after closing.

📌 Example:
🏡 You close on November 10th
❌ No mortgage payment in November
❌ No mortgage payment in December
✅ Your first payment is due January 1st

👉 The skipped payment happens because interest is prepaid at closing—not because you’re getting free months.

### Skipping Two Mortgage Payments When Refinancing

(02:22) Refinancing is where skipping two payments becomes possible. Here’s how:

1️⃣ Skip one payment from your current lender
2️⃣ Skip one payment from your new mortgage

📌 Example:
🔹 You close your refinance on November 5th
🔹 You don’t pay your November mortgage payment (because the loan is being paid off)
🔹 You don’t pay a December mortgage payment (because your new loan covers prepaid interest)
✅ Your first payment on the new loan starts January 1st

### Is Skipping Payments a Trick to Save Money?

(04:00) No! Some borrowers think skipping payments is a way to cheat the system—but that’s not true.

🚨 Reality Check:
🔹 You’re not getting free months—you’re just rolling interest into the payoff.
🔹 The bank always gets paid—whether it’s from your pocket or included in the refinance.
🔹 It’s like squeezing a balloon—the amount stays the same, it just shifts.

(05:03) Some people hear advice like:
🗣️ “Always close at the end of the month to save money.”
🗣️ “Closing early in the month means you pay more.”

✅ These are myths! The bank calculates interest daily, and your payoff is mathematically precise—it doesn’t matter when you close.

### Final Thoughts: What You Need to Know

(06:08) Skipping two mortgage payments when refinancing is real, but:
✔️ It’s not free—interest is still owed.
✔️ Your lender structures the loan to roll interest into the payoff.
✔️ It only works if you refinance early in the month.

(07:14) Have questions? 📩 Reach out to us!
✅ Email us at: Contact Form
✅ Like & comment if you found this helpful.

🏡 Need a refinance? We’re here to help!
