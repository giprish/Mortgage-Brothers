Original URL: https://azmortgagebrothers.com/how-to-count-commissions-and-bonuses-and-tips/
Page Title: How to Count Commissions, Bonuses, & Tips for Your Mortgage
Meta Title: How to Count Commissions and Bonuses and Tips
Meta Description: This episode covers how to count commissions, bonuses, and tips when it comes to getting conventional, VA, or FHA loans. Conventional Loans What’s important to know is that you need to have 12 months of history receiving commission or bonus income.
Canonical URL: https://azmortgagebrothers.com/how-to-count-commissions-and-bonuses-and-tips/
H1: How to Count Commissions and Bonuses and Tips

This episode covers how to count commissions, bonuses, and tips when it comes to getting conventional, VA, or FHA loans.

Unsure How to Count Your Bonuses and Tips?

Learn how to include commissions, bonuses, and tips as income for your mortgage application. Get expert advice today!

Get Help with Mortgage Income Requirements

## Conventional Loans

What’s important to know is that you need to have 12 months of history receiving commission or bonus income. It should be noted that it can come from multiple employers. So, it’s okay if your bonuses or commissions come from one employer for six months and a different employer for the other six. We can combine those for conventional loans. That being said the industries need to be similar. It can’t be bonuses from selling water filters for the first six months and then bonuses you receive from haircutting for the next six.

## VA Financing

VA financing requires that these commissions or bonuses have to be received for 24 months, you cannot have any job gaps, and they must come from the same employer.

## FHA Financing

FHA financing is similar to conventional financing. You’ll need 12 months of receipts; however, you can’t combine two employers.

## How about tip income?

So, there are a lot of people making tip income. In these cases, you will typically need two years’ worth of tip income for conventional and VA and one year for FHA.

## To Summarize

### Conventional Loans

- Commissions and Bonuses are treated very similarly
- Conventional loans need 12 months receipt of commission/bonus with no job gap greater than 30 days
- It’s okay if borrower changed employers within the same industry and line of work
- Conventional requires 24 months of tip income, NO GAPS receipt, and the employer needs to confirm that the tip income is expected to continue

### VA Loans

- VA requires 24 months receipt on commission/bonus with no job gap greater than 30 days
- VA requires 24 months of tip income, NO GAPS receipt, and the employer needs to confirm that the tip income is expected to continue

### FHA Loans

- FHA requires 12 months receipt on commission/bonus with no job gap greater than 30 days
- FHA requires 12 months of tip income, NO GAPS receipt, and the employer needs to confirm that the tip income is expected to continue

If you have any questions about this or if you have any questions you’d like us to answer on our podcast, you can submit your questions using our contact form or give us a call at(602) 535-2171. Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

•••

Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

Mortgage Brothers LLC does not provide tax, legal, or accounting advice. This material has been prepared for informational purposes only. You should consult your own tax, legal, and accounting advisors before engaging in any transaction. Mortgage Brothers NMLS 1007154, NMLS #210917 and 1618695. Equal housing lender.

Discover effective strategies and tips on counting commissions and bonuses to strengthen your mortgage application. Expand your knowledge by learning how to use part of your commission income to qualify for a loan, finding out how a rapid rescore can boost your credit profile, exploring the process of relocating and getting a mortgage while working remotely, and understanding why a DSCR loan might be the best alternative to hard money.

---

## Transcript of the Mortgage Brothers Podcast

### How Lenders Consider Commissions, Bonuses, and Tips for Mortgage Approval

(00:02) 🎙 Welcome to the Mortgage Brothers Podcast! I’m Eddie Knoell, and I’m Tom Knoell.

Today, we’re covering a key topic that affects a lot of borrowers:

💰 How do commissions, bonuses, and tip income count when applying for a mortgage?

If your income includes commissions, bonuses, or tips, you might be wondering:

- Can I use this income to qualify for a loan?
- How long do I need to show earnings?
- Are there different rules for different mortgage types?

Let’s break it all down.

### Commissions & Bonuses: How Do They Factor Into Mortgage Qualification?

(00:41) 📌 Lenders need proof of steady earnings before considering commissions & bonuses as income.

🏦 Loan Type Requirements:
✅ Conventional Loans (Fannie Mae & Freddie Mac): At least 12 months of documented history.
✅ VA Loans: A full 24 months of consistent earnings, with no job gaps and the same employer.
✅ FHA Loans: 12 months of documented earnings, but must be from one employer only.

🚀 Switching Employers?

- Conventional loans allow earnings from multiple employers (as long as it’s the same type of work).
- VA & FHA require income to come from a single employer for the required period.

📌 Example:
If you earned commissions selling water filtration systems for 6 months, then switched to selling home appliances for another 6 months, that counts under conventional loans (since it’s the same type of sales).

🚨 However, if you switched from sales to hairstyling, the new commissions wouldn’t count toward your mortgage income.

### Tip Income: How Lenders View It

(03:09) Tip-based income is assessed differently than commissions and bonuses.

✅ Conventional & VA Loans: 2 years of reported tip earnings required.
✅ FHA Loans: Only 1 year of reported earnings needed.

💡 Think of tip income like self-employment earnings.

- Lenders want to see a steady, documented income history.
- This is why VA & Conventional loans require 2 years, but FHA allows just 1 year.

📌 How do lenders verify tips?

- If tips are paid via credit card, they’re documented on pay stubs and W-2s.
- If you receive cash tips, they only count if you report them on your tax returns.

🚨 Not reporting cash tips?
If your tax returns don’t reflect tip earnings, lenders won’t include them, even if you’ve been earning tips for years.

💡 Pro Tip: If your income includes tips, ensure they’re properly reported on your pay stubs or tax returns so they can help you qualify for a mortgage!

### Common Myths About Commission, Bonus & Tip Income

🚫 “I’ve been getting tips/bonuses for 9 months—can I use that income?”
No. You need at least 12 months for conventional/FHA loans and 24 months for VA loans.

🚫 “I switched jobs recently—can I still count my commissions?”
It depends. If it’s a conventional loan and you stayed in the same field, you can combine income from multiple employers. VA & FHA loans require one employer.

🚫 “I receive cash tips but don’t report them—will they count?”
No. Only documented tip income (from tax returns or pay stubs) can be used for mortgage qualification.

### Key Takeaways

✅ Commissions & bonuses require at least 12 months (conventional/FHA) or 24 months (VA).
✅ Tip income requires 2 years (Conventional & VA) or 1 year (FHA).
✅ Cash tips must be reported on tax returns to count toward your mortgage application.

💰 Need help figuring out how much income you can use for a mortgage?
📩 Contact us for a free consultation!

### Have Questions? Contact Us!

🏡 Need a mortgage? Request a free quote—we’ll walk you through every step!

🎯 Thanks for tuning in—see you in the next episode!
