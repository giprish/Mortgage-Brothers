Original URL: https://azmortgagebrothers.com/lsu-forms-loan-status-updates-and-what-you-need-to-know/
Page Title: LSU Forms: Loan Status Updates & What You Need to Know
Meta Title: LSU Forms – Loan Status Updates and what you need to know
Meta Description: We go through the LSU (Loan Status Updates) which is an Arizona specific form. This is an important form that lenders will need to send to the sellers throughout the purchase transaction. We give our insight on the form and highlight the items we think are important for seller, buyers, and Realtors to be looking at.
Canonical URL: https://azmortgagebrothers.com/lsu-forms-loan-status-updates-and-what-you-need-to-know/
H1: LSU Forms – Loan Status Updates and what you need to know

We go through the LSU (Loan Status Updates) which is an Arizona specific form. This is an important form that lenders will need to send to the sellers throughout the purchase transaction. We give our insight on the form and highlight the items we think are important for seller, buyers, and Realtors to be looking at.

Need Help Understanding LSU Forms Loan Status Updates?

LSU Forms Loan Status Updates keep you informed during the mortgage process. Learn how they work and why they matter.

Get Expert Mortgage Advice

Keep up with the latest on loan status updates and essential forms. Enhance your understanding by reviewing our guide on inspection notices and seller responses and learning about the prequalification form. Additionally, stay informed on mortgage rates and interest deductions, understand prepayment penalties, discover tips on buying down your interest rate, explore second mortgage options, and follow capital gains updates.

---

## Transcript of the Mortgage Brothers Podcast

### Arizona LSU Forms (Loan Status Updates): What You Need to Know

(00:02) 🎙 Welcome to the Mortgage Brothers Podcast! I’m Eddie Knoell, and I’m Tom Knoell. This is our 16th episode, and today we’re diving into something essential for buyers, sellers, and agents:

📌 Loan Status Updates (LSU Forms)

🚨 Not to be confused with LSU football! These forms act as love notes to the sellers, keeping them updated on the progress of the buyer’s loan.

### What is an LSU Form & Why Does It Matter?

(00:45) 🏡 When you’re buying or selling a home, the LSU is a critical document that updates the seller on how far along the buyer’s loan process is.

👉 Why sellers care:

- Sellers are waiting on the buyer’s loan to be finalized before they can close.
- They already have a pre-qualification form, but the LSU gives real-time updates.

📜 The Arizona Association of Realtors (AAR) requires LSU forms, just like purchase contracts and pre-qualification forms.

✅ LSU Timeline:

- The contract requires buyers to send at least one LSU to the seller.
- Due within 10 days of contract acceptance (but many lenders send them much earlier).
- Our team sends LSU within 2-3 days to keep things moving smoothly.

### Breaking Down the LSU Form

(01:46) The LSU form is two pages long and contains two key sections:

1️⃣ Page 1: Mostly repeats the information from the pre-qualification form (loan type, amount, property address, buyer & seller details).
2️⃣ Page 2: A detailed checklist of loan milestones, showing what’s been completed and what’s still pending.

📑 How It Works:

- Buyers receive the LSU via DocuSign and sign it to acknowledge the status update.
- The lender then forwards it to the seller’s agent and the buyer’s agent.

### LSU Page 2: Key Loan Milestones

(04:43) 📌 Think of this section like a grocery list—a series of checkboxes confirming different stages of loan approval.

Here’s what each line means:

### Step 1: Contract & Loan Setup

✅ Line 41: Has the lender received the purchase contract & addendums?
✅ Line 42: Has the lender sent out the Loan Estimate (LE)?
✅ Line 43: Has the borrower signed the Intent to Proceed?
✅ Line 48: Has the borrower paid for the appraisal?
✅ Line 49: Has the appraisal been ordered?

💡 Why this matters:

- The loan estimate must be sent within 3 days of the application.
- Borrowers must sign the Intent to Proceed before appraisals can be ordered.

### Step 2: Interest Rate & Loan Details

✅ Line 52: Has the buyer locked in their interest rate and loan program?

🚨 Red flag: If this box is marked NO, the buyer may not be fully committed to their lender yet.

### Step 3: Appraisal & Property Value

✅ Line 55: Has the appraisal been received?
✅ Line 56: Did the appraisal come in at or above purchase price?
✅ Line 61: Have all appraisal conditions been met?

💡 Why this matters:

- If the appraisal is below purchase price, the buyer and seller may need to renegotiate.
- If the appraisal requires repairs, they must be completed before final loan approval.

### Step 4: Loan Approval Process

✅ Line 59: Has the lender submitted the loan package to underwriting?
✅ Line 60: Has the loan received initial approval with conditions?

📝 Key point:

- Initial approval often comes with conditions—small missing documents or clarifications.

✅ Line 62: Has the loan received final approval (clear to close)?

🎉 This is the BIG ONE! The final approval means the loan is ready for closing & funding.

### Step 5: Final Loan Documents & Closing

✅ Line 57: Has the Closing Disclosure (CD) been sent to the buyer?
✅ Line 58: Has the buyer acknowledged the CD (starts the 3-day waiting period)?
✅ Line 63: Have the loan documents been sent to title?
✅ Line 64: Have the buyers signed their final loan documents?

📌 Remember:

- The Closing Disclosure must be signed at least 3 days before closing.
- Loan docs must be signed before escrow can officially close.

### Final Thoughts: Why LSU Forms Matter

(12:58) Sellers rely on LSU updates to feel confident in the transaction.

🚀 Buyers & agents should:
✔️ Send LSU updates quickly after contract acceptance.
✔️ Make sure LSU forms accurately reflect loan progress.
✔️ Understand that missing items may slow down closing.

💡 Good news: If everything is checked off early, buyers may close ahead of schedule!

(14:02) Questions? 📩 Contact us!
✅ Email us at: Contact Form
✅ Like & subscribe if this helped you!

🏡 We’re here to make the mortgage process smooth & stress-free!
