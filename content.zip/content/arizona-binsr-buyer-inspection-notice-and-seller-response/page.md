Original URL: https://azmortgagebrothers.com/arizona-binsr-buyer-inspection-notice-and-seller-response/
Page Title: Arizona BINSR Buyer Inspection Notice & Seller Response
Meta Title: Arizona BINSR Buyer Inspection Notice & Seller Response
Meta Description: Learn how the Arizona BINSR process works, what buyers and sellers need to know, and how to handle repair requests in a home sale.
Canonical URL: https://azmortgagebrothers.com/arizona-binsr-buyer-inspection-notice-and-seller-response/
H1: Arizona BINSR Buyer Inspection Notice and Seller Response

by

| Feb 4, 2025

Lenders are not involved in the BINSR process directly. We want to discuss how the BINSR and home inspection process affects a mortgage indirectly.

1. Buyer has 10 days by default on the Purchase contract to do their home inspection
2. Buyer uses the BINSR form to respond to the seller with any items they would like repaired or remedied
3. Seller has 5 days to reply to the buyers request

https://youtu.be/vShVhawZyn4

Need Help Navigating the Arizona BINSR Process?

Understanding the BINSR process is crucial for buyers and sellers. Get expert guidance to ensure a smooth home sale.

Get Expert Advice

Lenders need to order the appraisal with no less than 21 days from the close of escrow…, that being said we typically like to wait to order the appraisal after the BINSR has been negotiated OR when we receive a clear signal that there are no deal killers in the home inspection. Lenders should have a conversation about this with buyers and buyers agent to set their expectations.

Buyer and Seller should finalize any seller concessions through the standard contract addendum and not through the BINSR. This helps us keep underwriters looking at the BINSR and any inspection issues with the home. That can open up a can of worms.

If you have any questions about this or if you have any questions you’d like us to answer on our podcast, you can submit your questions using our contact form or give us a call at(602) 535-2171. Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

•••

Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

Mortgage Brothers LLC does not provide tax, legal, or accounting advice. This material has been prepared for informational purposes only. You should consult your own tax, legal, and accounting advisors before engaging in any transaction. Mortgage Brothers NMLS 1007154, NMLS #210917 and 1618695. Equal housing lender.

Discover the ins and outs of buyer inspection notices and seller responses. For more insights, check out our guide on the prequalification form, learn about mortgage rates & interest deductions, review details on prepayment penalties, find strategies for buying down rates, explore second mortgage options, and see why capital gains are back.

---

## Transcript of the Mortgage Brothers Podcast

### Arizona BINSR: Buyer Inspection Notice and Seller Response Addendum

### Introduction

[00:02]Welcome to the Mortgage Brothers Podcast Show! I’m Eddie Knoell, and I’m Tom Knoell. Today, we’re discussing an essential part of the home buying process in Arizona: the BINSR—Buyer Inspection Notice and Seller Response Addendum.

Many buyers and sellers misunderstand how this form works, and in this episode, we’ll break it down in simple terms.

### What is the BINSR?

[00:39]The BINSR is a formal process within Arizona’s real estate transactions that allows buyers to notify the seller of any issues found during a home inspection. It also provides a way for sellers to respond to those concerns.

Once you go under contract, you typically have 10 days to complete your inspections and submit the BINSR to the seller. This is a critical step that allows buyers to request repairs, negotiate credits, or even cancel the purchase based on inspection findings.

### Key Sections of the BINSR

[01:46]The BINSR form consists of:

1. The Buyer’s Notice – The buyer lists any requested repairs, asks for a price reduction, or states they are accepting the property as-is.
2. The Seller’s Response – The seller has the option to agree to all, some, or none of the buyer’s requests.
3. The Buyer’s Final Decision – After receiving the seller’s response, the buyer must decide whether to proceed with the purchase or cancel the contract within the time frame specified.

### What Happens After the BINSR is Submitted?

[03:10]Once the buyer submits the BINSR, the seller has 5 days to respond. Here’s what can happen:

- The seller agrees to all the requested repairs.
- The seller agrees to some but not all requested repairs.
- The seller declines all requests, leaving the buyer to decide whether to proceed or cancel the contract.

If the seller offers a partial repair list, the buyer has 5 additional days to accept or walk away.

### Common Mistakes Buyers Make

[04:37]Buyers often misunderstand how the BINSR process works. Here are a few common mistakes:

- Requesting non-essential cosmetic repairs – Sellers are more likely to agree to safety or structural concerns than minor cosmetic issues.
- Not understanding that sellers aren’t obligated to fix anything – The seller can reject all repair requests, and it’s up to the buyer to decide what to do next.
- Submitting unrealistic demands – This can lead to the seller rejecting the entire request, potentially causing unnecessary conflicts.

### Common Seller Mistakes

[06:38]Sellers also make missteps when responding to the BINSR:

- Automatically rejecting all requests – This can result in the buyer walking away, causing delays in selling the home.
- Ignoring the importance of negotiations – Sellers should carefully consider reasonable repair requests rather than dismissing them outright.
- Misunderstanding appraisal impacts – Some repairs may be required for financing (FHA, VA loans), so rejecting them could cause financing issues for the buyer.

### Negotiating the BINSR Successfully

[08:44]Both buyers and sellers should approach the BINSR with realistic expectations. The key to a smooth negotiation process is:

1. Understanding the home’s condition – If the house is older, some repairs should be expected.
2. Prioritizing safety and structural repairs – Sellers are more likely to agree to fixes related to electrical, plumbing, roofing, and HVAC systems.
3. Compromising when needed – Both parties should be willing to negotiate and find a middle ground.

### Final Thoughts

[10:52]The BINSR is not meant to be a second round of price negotiation—it’s a tool to address real concerns that could impact a home’s livability and safety.

Understanding how to navigate this process can help buyers protect their investment and sellers close the deal smoothly.

### Need More Help?

[11:49]If you have any questions about the Arizona BINSR or the home-buying process, feel free to reach out to the Mortgage Brothers Team. Don’t forget to like, comment, and subscribe for more mortgage and real estate insights.
