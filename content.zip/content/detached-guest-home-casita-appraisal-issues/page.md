Original URL: https://azmortgagebrothers.com/detached-guest-home-casita-appraisal-issues/
Page Title: Detached Guest Home Appraisal Issues Explained
Meta Title: Detached Guest Home (Casita) Appraisal Issues
Meta Description: Understand how detached guest homes and casitas are appraised, why they get low line-item adjustments, and what that means for financing.
Canonical URL: https://azmortgagebrothers.com/detached-guest-home-casita-appraisal-issues/
H1: Detached Guest Home (Casita) Appraisal Issues

In this episode, we covered issues that might arise when you receive an appraisal on your detached guest home, also know as a casita.

There are three perspectives to consider:

- Refinancing perspective
- Purchasing perspective
- Building perspective

We’re just going to give you the quick overview here, but for the full details, be sure to listen to the episode in the video above or on Apple Podcasts. Let’s get into it.

Concerned About Your Casita’s Appraisal?

A detached guest home can complicate appraisals and financing. Get expert advice on maximizing value and avoiding common pitfalls.

Get a Free Home Appraisal Review

## Refinancing Perspective

If you purchase a home and the casita is already on the lot when you receive your appraisal, you’re going to notice that your casita will not be included in the home square footage, rather it will be included as a line item adjustment. If your house had a casita when you purchased it go back and take a look at the appraisal and you’ll notice that there was a line item adjustment for it then too. When you are refinancing, make sure you have all the information in front of you. If you’re refinancing for rate and term, you want to get the maximum value for your home so that your loan-to-value is as low as possible.

## Purchasing Perspective

Appraisers most often come up with these values from sales of comparable homes that were recently sold. Now, casitas and guest houses are rare, so the sample size is a lot smaller than that of property without, which is one complication when it comes to getting accurate appraisals.

Unlike when it comes to refinancing, the traditionally low appraisal of casitas can be wonderful from a purchasing perspective.

## Building Perspective

It’s generally going to be hard to build a casita for less than around $70,000. We’d say the average rate is somewhere between $70,000 and $120,000. However, if you get an appraisal for it the line item will likely only say something around $20,000 or so. This isn’t to say casita’s can’t be worth it, but it’s something to keep in mind.

We’ve also received a few questions about attaching guest houses to your main home. In these cases, be sure to talk to your city first since it has to be coded and there is a permitting process involved. That being said, it is possible in a situation where it’s close enough and it makes sense. In the cases where you can attach it and it flows, if it’s a part of the main living dwelling then the appraiser will treat it as one level.

## To Summarize

The square footage is not added to the main living area of the primary home.

The appraiser only gives a line item adjustment for a guest house.

It is common to have an adjustment of only $20,000 for a guest house even though it could have cost $100,000 to build.

Appraisers need to use comparable sales that have detached guest houses, which is hard to do.

Guesthouses are hard to compare because they are going to vary greatly in age, quality, and size.

If you have any questions about this or if you have any questions you’d like us to answer on our podcast, you can submit your questions using our contact form or give us a call at (602) 535-2171. Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

•••

Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

Mortgage Brothers LLC does not provide tax, legal, or accounting advice. This material has been prepared for informational purposes only. You should consult your own tax, legal, and accounting advisors before engaging in any transaction. Mortgage Brothers NMLS 1007154, NMLS #210917 and 1618695. Equal housing lender.

Uncover common appraisal issues related to detached guest homes. To get a broader perspective, compare with our guide on the differences between owner-occupied second homes and investment properties, see how connecting a guest house to your main home can boost value, and review the contrast between Arizona condos and townhomes.

---

## Transcript of the Mortgage Brothers Podcast: Detached Guest Homes (Casitas) and Appraisal Challenges

(00:02) 🎙 Welcome to the Mortgage Brothers Podcast! I’m Eddie Knoell, and I’m Tom Knoell. This week, we’re diving into casitas— detached guest homes—and how they impact property value and mortgage appraisals. Whether you call them man caves, woman caves, Airbnb rentals, or guest houses, if it’s detached from the main house, we’re calling it a casita today.

(00:46) ✅ If you’re watching on YouTube, subscribe to stay updated on our weekly episodes. We drop new content every Tuesday!

(01:19) Now, why are we talking about casitas? I’ve actually considered building one myself, but every time I crunch the numbers, I hesitate. The big question is: Will I get my money back? That’s what we’re covering today—how casitas affect home value, particularly for homeowners looking to refinance.

### Casitas and Home Appraisals for Refinancing

(02:35) If you purchased a home that already had a casita, here’s what happens when you refinance:

✔️ Your casita will NOT be included in your home’s total square footage.
✔️ If you have a 3,000 sq. ft. home and a 1,000 sq. ft. casita, the appraiser will not count it as 4,000 sq. ft.—only the main house is included.
✔️ Instead, appraisers make a line-item adjustment for the casita, typically between $15,000 – $30,000, regardless of the actual construction cost.

(03:12) Many homeowners expect their casita to add significant value, but when they see that low line-item adjustment, they’re shocked. We get calls like:

🔹 “The appraiser must have made a mistake! My casita cost me $100K to build—why is it only valued at $20K?”
🔹 “Can you call the appraiser and fix this?”

(03:42) The truth is, this isn’t a mistake—this happens every time with detached guest homes. If you check your original appraisal from when you purchased your home, you’ll see the same low valuation for the casita.

(04:11) The frustration usually comes during rate and term refinances, where homeowners are looking for maximum home value to get the best loan terms.

### What If You Build a New Casita? Will It Increase Your Home Value?

(04:43) Many homeowners think:
💡 “I’ll build a casita for $80,000 and do a cash-out refinance to recover my investment.”

🚨 Reality Check: Even if you spend $70K – $120K on a casita, the appraisal will likely only add $20K – $30K to your home’s value.

(05:51) Some homeowners argue that their casita provides more value than the appraiser’s number suggests. While an appraiser may only give it a $20K adjustment, the main home might also receive an indirect value boost.

📌 Appraisers would deny this happens, but we believe some of the value gets absorbed into the main home’s appraisal price—what we call “stolen value.”

(06:33) Example:
🔹 You buy a 3,000 sq. ft. home with a 1,000 sq. ft. casita for $600K.
🔹 The appraiser finds comps but still values the casita separately at $20K-$30K rather than adding its full worth to the property.
🔹 The final appraised value may reflect the casita’s presence, but it won’t be itemized at its true construction cost.

(07:11) Appraisers stick to comps. They don’t value casitas based on construction cost but rather on comparable sales of similar homes with guest houses.

### Why Are Casitas Valued So Low in Appraisals?

(07:48) Appraisers look at comparable sales of homes with casitas. The problem?

❌ Casitas are rare, so it’s difficult to find matching sales.
❌ Many casitas vary in size, quality, and function (some are luxury guest homes, others are converted garages).
❌ A casita built for Airbnb rental or family use might hold high personal value, but that doesn’t mean it translates to higher appraisal value.

(08:21) It’s like dating—you’re looking for someone your age, with shared interests, and similar values. Finding a perfect match isn’t always easy, and finding the right comparable sales for casitas is just as difficult.

(08:54) Some casitas are old, run-down converted sheds, while others are high-end guest homes. Appraisers struggle to find identical comparisons, which is why values vary so much.

### Buying a Home with a Casita? What to Expect

(09:29) If you’re buying a home with a casita, here’s the good news:

✔️ The appraised value may come in lower than the purchase price—meaning you could get a deal!
✔️ Appraisers often undervalue casitas compared to what buyers are willing to pay.

(09:59) However, if the seller overprices the home, the appraisal might come in low, requiring either:
🔹 Price negotiations between buyer & seller
🔹 More cash from the buyer to cover the appraisal gap

(10:27) Some buyers place higher personal value on casitas than appraisers do—especially if they plan to use them as:
✔️ In-law suites
✔️ Short-term rentals (Airbnb, VRBO, etc.)
✔️ Home offices or creative studios

(11:01) In these cases, buyers may pay more than appraised value because, to them, the casita is worth it.

### What About ATTACHED Guest Homes?

(11:36) 🚀 What if I connect my casita to my main home with a hallway?

📌 It must be a single dwelling, not just a long hallway. If the city and zoning laws recognize it as an addition, it may be counted in total square footage.

(12:22) The “Red Face Test”: If you tell someone your casita is “attached” but it’s 80 feet away with a hallway, it doesn’t pass the red face test—meaning it’s probably still considered detached.

(12:56) To count as attached, the structure must be integrated into the main dwelling and meet building codes.

### No, Appraisers Aren’t Out to Get You!

(13:29) Some homeowners believe in a conspiracy—that appraisers intentionally undervalue homes. The truth?

✔️ Appraisers follow strict guidelines—they aren’t just making up numbers.
✔️ If they inflated values, banks wouldn’t accept the loans.
✔️ They’re using market comps, not personal opinions.

(14:00) Yes, appraisals can feel unfair, but once you understand how appraisers calculate values, it all makes sense.

### Final Thoughts on Casitas and Appraisals

(14:33) Key Takeaways:
✔️ Casitas are always appraised separately from the main house.
✔️ Expect a low line-item adjustment (often just $20K-$30K).
✔️ If you build a casita, don’t expect a dollar-for-dollar increase in home value.
✔️ If you’re buying a home with a casita, you might get a better deal than expected.

(15:02) Subscribe for more mortgage tips! Got questions? Reach out to us at:
📩 Email: Contact Form
🏡 Need a mortgage? Let’s chat!
