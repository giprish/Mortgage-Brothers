Original URL: https://azmortgagebrothers.com/mortgage-101/
Page Title: Mortgage 101: Your Guide to Home Financing
Meta Title: Mortgage 101: Your Guide to Home Financing
Meta Description: Discover Mortgage 101 fundamentals with expert insights from Arizona Mortgage Brothers to kickstart your home financing journey.
Canonical URL: https://azmortgagebrothers.com/mortgage-101/
H1: Arizona Mortgage 101

# Arizona Mortgage 101

Since there are so many components to the AZ mortgage process, we have taken special care to organize the most important qualifying steps, lending frequently asked questions, home buying and mortgage processes below. We realize that that the information contained in this site could literally take you weeks to research and digest, so please feel free to call us at any time for a personal consultation where we can address your specific needs and questions.

You’ve Mastered the Basics—Now Connect with the Experts

Now that you’ve learned the fundamentals, reach out to us. We’re professional mortgage experts ready to guide you to the next step.

Contact Us Today

#### Arizona Mortgage Basics

What is a mortgage, and who owns my home if I have secured financing to purchase it? Whether you’re new to the home buying process, or a seasoned investor, I bet you didn’t realize that there are at least 20 top mortgage related terms that you may want to understand prior to speaking with a real estate agent or loan officer. This section highlights some of the basic math and topics of interest that will help you get started on your home buying and financing journey.

#### Why Use an Arizona Mortgage Broker?

Getting a mortgage loan can seem like a daunting and even scary task, but it doesn’t have to be that way if you do your research and work with the right people who can get your loan approved and get you into your new home. Using a mortgage broker means you will have access to a number of different banks and other lenders who may each have different guidelines for approval, thereby raising the chances that one of those lenders will be able to say yes to your mortgage loan so you can head to closing. Arizona mortgage brokers also work in the evenings and on weekends in many cases to make sure they give their all to their clients and help them as much as possible, so you won’t be out of luck if you have a question or need to send loan documentation during hours that are not nine to five, Monday through Friday.

#### Mortgage Approval Process

Required down payment, income/employment information and credit standing are a few of the important factors lenders look at when considering a borrower for a mortgage loan approval. There are several questions that a loan officer needs to ask before a simple pre-approval letter can be issued. But more importantly, there are at least 8 top questions that you should be asking your lender before taking any steps to fill out an application. Being prepared with the proper documents and personal information will allow you to spend more quality time with your loan officer addressing the important points of your pre-approval and mortgage program options.

#### Understanding Your Credit

Your credit picture plays a key role in the mortgage approval process, and it is essential to understand how scores are measured and calculated. Should you close all cards or keep them open? What if you don’t have any credit history that shows up on a report, is there a way to use cell phone and utility bills? In this section, you’ll learn the basic rules about preparing your credit standing prior to speaking with a lender for qualification.

#### Mortgage Payments

In addition to mortgage rates, there are many other obligations that factor into your overall mortgage payment. HOA Dues, Hazard Insurance, Home Warranties, Property Taxes… to name a few. It helps to be aware of the expenses involved in owning real estate in order to set a monthly budget that is true to your financial goals and expectations.

#### Mortgage Programs

It’s amazing how many mortgage programs have been designed to help First-Time Borrowers get financing on new homes. Before you start shopping for a listing that fits your living needs, it would be extremely beneficial to know what type of lending scenario best fits the type of property or neighborhood you’re looking to buy in. With regards to a refinance, you may actually qualify for a new government sponsored program that has been designed with current market conditions in mind.

#### Home Buying Process

What comes first – the approval or the purchase contract? Once you have weighed the basic pros and cons of owning a home vs renting, tax benefits and timely market influences, assembling a winning team of real estate and mortgage professionals will help you cover all of your bases. There are also some very important time lines that you’ll need to be aware of, such as appraisal, home inspection and loan approval dates. Can the type of Home Owners Association affect your loan approval? Absolutely. If you’re feeling a little anxious at this point, then that just means you’re actually taking this home buying thing seriously. Don’t worry, we’ll make sure you are kept in the loop throughout the entire home buying process.

#### Closing Process

With the right home buying team on your side, the closing process should be a smooth transition from signed documents to closing. The excitement has been building throughout the entire process from home shopping to mortgage approval; so it’s easy to overlook some important details at the end. Understanding the industry lingo will certainly help you avoid feeling like you’re on a roller-coaster while all the team players come together at the end to perform doc signings, pre-closing conditions… It also helps to know about all of the fees associated with a new home purchase or refinance. Understanding the difference between the fixed and variable fees will help you set a more accurate budget, which could impact whether or not you get your earnest money back at closing.

#### Mortgage Closing Costs

The closing costs associated with a mortgage can seem very confusing if you haven’t been given information on them, or if you’ve never purchased a home before, because you don’t know what to expect or why you are being asked to pay for items you may not understand. Rather than just pay what’s asked, you can have a higher level of peace of mind if you understand what all the fees are for and why you are expected to pay them, instead of asking the other party to the transaction to handle those expenses themselves. Understanding the closing costs means you can also be prepared for them and find out approximately how much they will add up to, so you won’t end up having to bring more money to the table than you really expected to close your real estate transaction.

#### Refinance Process

Properly estimating neighborhood property values and your closing costs will help determine the net benefit of a refinance transaction. Some homeowners just want to know the best approach of finding money to make home improvements, while other borrowers are in a situation where their rate is adjusting. Either way, it’s easy to get caught off guard if you don’t have the essential knowledge about your mortgage refinance options.

#### The Ultimate Guide to Your First Mortgage

The Phoenix Valley was recently voted out of the top 20 markets for first time buyers, highlighting a fact that most first time buyers have probably already noticed on their own: it’s getting more expensive to buy your first home. But don’t despair. You can still buy the home of your dreams, even if it will take more time and planning than might have been needed even just a year or two ago. In this guide, I’m going to give you all the insider tips on how you can get into your first home without paying too much.

#### What to Expect When You’re Not a First Time Mortgage Shopper

When you’re moving to Phoenix, or moving up to a new home within the area, one of the first things you need to do before visiting open houses, before finding a real estate agent or even deciding on a neighborhood, is to find a mortgage lender and understand how to secure a loan to buy a home. If you’ve bought a home before, you might have some experience with the process. But the mortgage industry has changed since your last loan. And if you’re new to the Phoenix Valley, you might not know who to call or what the process will look like here. Here’s an overview of what it’s really like to get a mortgage these days, and what you need to know and do to ensure you get the best loan for you.
