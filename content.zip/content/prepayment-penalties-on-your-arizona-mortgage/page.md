Original URL: https://azmortgagebrothers.com/prepayment-penalties-on-your-arizona-mortgage/
Page Title: Prepayment Penalties on Your Arizona Mortgage: What to Know
Meta Title: Prepayment Penalties on Your Arizona Mortgage
Meta Description: Learn how optional prepayment penalties work on Arizona mortgages, when they may lower your rate, and how to negotiate terms or avoid surprise fees.
Canonical URL: https://azmortgagebrothers.com/prepayment-penalties-on-your-arizona-mortgage/
H1: Prepayment Penalties on Your Arizona Mortgage

by

| Feb 4, 2025

Prepayment penalties are at the borrower’s option and are never mandatory requirements by the lender. Generally, prepayment penalties disappear after five years. The penalty is a percentage of the outstanding loan balance or it can be equal to a specific number of months of interest. If you want to pay 20% of your loan balance, there is no prepayment penalty for most loans.

A prepayment penalty may lower your interest rate by a ¼%. There are prepayment penalty options that apply to home purchase loans and prepayment penalty options that apply to refinance loans. Typically, borrowers with good credit don’t have to worry about choosing a loan with prepayment penalties on purchase loans or refinance loans because they get more favorable interest rates to begin with because of their better credit scores and favorable payment histories.

Worried About Prepayment Penalties?

Paying off your mortgage early shouldn’t come with extra fees. Get expert advice on avoiding prepayment penalties and saving money.

Get a Free Mortgage Review

## What to Know About Prepayment Penalties

If you do opt for an Arizona mortgage with a prepayment penalty, try and negotiate a prepayment period for no longer than five months, the ability to make a partial prepayment up to 20% of your loan balance at any time and that the prepayment penalty only applies if you refinance your home. If you have plans on staying in your home for more than five years, a prepayment penalty may not make a difference.

You should weigh all your options first before making a decision to obtain a mortgage with a prepayment penalty by comparing mortgage products without a prepayment penalty. Lenders must disclose to borrowers that their loan contains a prepayment penalty or face fines or penalties for violating lending and disclosure laws. The problem is many borrowers don’t pay attention or read their loan documents carefully and discover too late when they want to sell their home or refinance, that their Arizona mortgage contains a prepayment penalty clause.

The best way to way to avoid any surprises about your loan terms is to read them carefully first. Have your Arizona mortgage broker go over the terms with you before signing anything, or hire an attorney to review your loan documents to make sure you understand clearly what you are signing and your obligations, rights and responsibilities regarding your credit obligation.

If you have any questions about this or if you have any questions you’d like us to answer on our podcast, you can submit your questions using our contact form or give us a call at(602) 535-2171. Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

•••

Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

Mortgage Brothers LLC does not provide tax, legal, or accounting advice. This material has been prepared for informational purposes only. You should consult your own tax, legal, and accounting advisors before engaging in any transaction. Mortgage Brothers NMLS 1007154, NMLS #210917 and 1618695. Equal housing lender.

Learn what prepayment penalties mean for your Arizona mortgage. For further context, check out our guide on inspection notices, review the prequalification form, explore mortgage rates & interest deductions, get tips on buying down rates, consider second mortgage options, and see why capital gains are back.
