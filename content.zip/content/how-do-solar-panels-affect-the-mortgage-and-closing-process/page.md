Original URL: https://azmortgagebrothers.com/how-do-solar-panels-affect-the-mortgage-and-closing-process/
Page Title: How do Solar Panels affects mortgage and closing process?
Meta Title: How do Solar Panels affect the mortgage and closing process?
Meta Description: In this episode, we covered solar panels and how borrowers should view them when looking to buy. How do lenders view solar panels? Are they even allowed? Yes, in most cases, solar panels are allowed. When we do the loan, we want to make sure that the buyer gets a copy of the solar agreement.
Canonical URL: https://azmortgagebrothers.com/how-do-solar-panels-affect-the-mortgage-and-closing-process/
H1: How do Solar Panels affect the mortgage and closing process?

In this episode, we covered solar panels and how borrowers should view them when looking to buy.

Buying or Selling a Home with Solar Panels?

Solar panels can impact mortgage approval and the closing process. Get expert guidance to navigate financing and lender requirements.

Get a Free Mortgage Consultation

## How do lenders view solar panels? Are they even allowed?

Yes, in most cases, solar panels are allowed. When we do the loan, we want to make sure that the buyer gets a copy of the solar agreement that the owner has, we want to make sure that there is a warranty against all malfunctions and defects, and we want to make sure that the lease is transferable to our buyer regardless of whether the solar panels are leased or owned.

In someone’s solar panels are leased, they have to be transferred by the owner (a company such as Solar City) to the new buyer. But, if they are owned outright then there’s no loan and they are treated as a part of the real estate, a fixture of the property. However, if there’s a loan on there, that loan itself goes with the property as a lien, and it must be transferable to the new buyer.

One other thing to expect is that the solar company may do a credit check. That being said, there’s likely a higher threshold for qualifying for buying a house than for a solar lease, so this shouldn’t be too much of a concern.

## How do solar panels impact value?

If the panels are leased, appraisers will not count value. The reason for this is that the appraisal and the guidelines that came out by the institutions like Fannie Mae and Freddie Mac, the FHA, and the VA, view ownership of the panels means that you actually need to own the asset. If the solar panels are actually owned, rather than leased, you’re going to see a value adjustment on the appraisal, though you shouldn’t expect too much of a bump. If you spent $20,000 on your system, you might only see a $5000 adjustment. And in some cases, they don’t even show up if the comparable sales in the neighborhood don’t demonstrate that solar panels give value.

## How do solar panel payments potentially affect qualifications?

If there is a production guarantee in your lease agreement or the ownership agreement, the lender will not count the loan payment or the lease payment against you. In many cases, there’s a production guarantee which is when a solar company says, “If your solar system doesn’t produce so many kilowatts an hour for so many months, we’ll refund you.” This is one of the ways they justify being able to install the system while also protecting the borrower because if the borrower buys the system it’s their responsibility if something goes wrong with the cells or if they are defective.

One other thing to be aware of is not only are you going to be paying APS and SRP, the bill, but also, you’ll be paying this extra loan payment. So this warranty of a minimum guarantee will help.

As well, when we close the loan, if there is a lien right from the loan or a lease, the title company is going to be required to release that lien before we put our lien on. They want to release the lien of the solar company, and then put that back on afterward. Sometimes there is a modest fee associated with this and sometimes there’s no fee at all, but it’s a process that needs to be done, and the real estate agents, buyers, and everyone, by the end of the transaction, will be very familiar with how that all works.

If you have any questions about this or if you have any questions you’d like us to answer on our podcast, you can submit your questions using our contact form or give us a call at(602) 535-2171. Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

•••

Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

Mortgage Brothers LLC does not provide tax, legal, or accounting advice. This material has been prepared for informational purposes only. You should consult your own tax, legal, and accounting advisors before engaging in any transaction. Mortgage Brothers NMLS 1007154, NMLS #210917 and 1618695. Equal housing lender.

Learn how installing solar panels can influence your mortgage and the closing process. To understand the broader financial landscape, check out our insights on mortgage rates and deductions and prepayment penalties. You might also review our article on inspection notices for related topics.

---

## Transcript of the Mortgage Brothers Podcast

### How Do Solar Panels Affect the Mortgage & Closing Process?

(00:02) 🎙 Welcome to the Mortgage Brothers Podcast! I’m Eddie Knoell, and I’m Tom Knoell. Today, we’re diving into a hot topic for homeowners and buyers:

☀️ Solar Panels: How Do They Impact Your Mortgage & Closing?

💡 Are solar panels always a bright idea, or do they come with storm clouds when it comes to financing? Let’s break it down.

### Are Solar Panels Allowed in Mortgage Loans?

(00:36) ✅ Yes, lenders allow solar panels!

However, they fall into two categories:
1️⃣ Owned panels – The seller owns the panels outright.
2️⃣ Leased panels – The panels are owned by a solar company, and the homeowner is making lease payments.

🏡 Why does this matter?

- Lenders need to review the solar agreement before approving a loan.
- The buyer must get a copy of the agreement and provide it to the lender.
- If the panels are leased, the lease must be transferable to the new buyer.

### Why Does Transferability Matter?

(01:46) 🔄 If the solar lease isn’t transferable, the deal can fall apart.

🔍 Buyers should check:
✅ Does the solar lease include a warranty for malfunctions?
✅ Can the buyer take over the lease without restrictions?
✅ Does the solar company require a credit check for the new owner?

📌 Key point: If the panels are owned outright, they transfer automatically with the home, just like any other fixture. But if there’s a loan or lease attached, the seller may need to pay off the balance before selling.

### How Do Solar Panel Leases Impact Buyers?

(03:59) 🔍 What do buyers need to know?

- If the panels are leased, the buyer must qualify to take over the lease.
- Some solar companies will run a credit check on the buyer.
- If the lease isn’t transferable, the seller may need to buy out the contract before closing.

💰 Will the seller pay off the loan?

- Sometimes, sellers offer to pay off the remaining balance to make the home more attractive.
- Buyers should ask about the payoff amount before making an offer.

🚨 Pro Tip: If a home has leased panels, check with the solar company early in the process to avoid last-minute surprises!

### How Do Solar Panels Affect Home Value?

(05:38) 💰 Do solar panels increase home value?

✅ Owned solar panels can increase value, but not as much as most people think.
❌ Leased panels do NOT increase the appraised value of the home.

### How Do Appraisers Handle Solar Panels?

(06:19) 🏠 Appraisers follow lender guidelines:

- Leased panels = No value added 🚫
- Owned panels = Some value added (but not always a full return on investment)

📌 Why don’t leased panels add value?

- The homeowner doesn’t actually own them.
- Lenders see them like a car lease—you don’t own the asset, so it’s not counted.

📉 What if the panels are owned?

- Even if the seller paid $20,000 for the system, appraisers may only add $5,000 in value.
- If there are no comparable homes with solar panels, the appraiser may not adjust the value at all.

### How Do Solar Panel Payments Affect Mortgage Qualification?

(09:39) 🔍 If the buyer takes over a lease, will the payment count against their mortgage qualification?

✅ It depends. If the lease includes a production guarantee, lenders won’t count it in debt-to-income (DTI) calculations.

🚨 What’s a production guarantee?
A solar company promises that the panels will produce a set amount of electricity. If they don’t, they refund the homeowner.

📌 Why does this matter?

- Without a production guarantee, lenders may count the lease payment as debt, reducing the buyer’s borrowing power.
- Buyers should check their loan pre-approval to see if the solar lease affects their DTI ratio.

### How Do Solar Panels Affect the Closing Process?

(11:18) 🔄 Title Companies Must Release Solar Liens

If the solar panels are financed, there is usually a lien on the property.

🏡 Before closing, the title company must:
✅ Get the solar company to release the lien.
✅ Add the new buyer’s name to the lease (if applicable).
✅ Re-file the lien after closing (if the lease continues).

📌 Fees: Some solar companies charge $200–$500 to transfer the lien.

🚨 Pro Tip: Work with the title company early in the process to avoid delays.

### Final Thoughts: Should Buyers Be Worried About Solar Panels?

(14:45) ☀️ Solar panels can be a great investment, but buyers should:
✅ Ask for a copy of the lease or loan agreement early.
✅ Check if the lease is transferable.
✅ Verify whether the solar payment affects their mortgage qualification.
✅ Understand that appraisals may not fully reflect the system’s cost.

💡 Long-term outlook: Solar technology is improving, and costs are dropping. While solar panels may not add much value today, they can offset rising electricity costs in the future.

### Got Questions? Contact Us!

🎯 Need a mortgage? Ask us for a free quote—we’ll guide you through every step!

🏡 Thanks for tuning in—see you in the next episode!
