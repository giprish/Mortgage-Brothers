Original URL: https://azmortgagebrothers.com/get-part-income-commission-can-use-qualify-loan/
Page Title: Will Commissions Count Towards a Loan? What You Need to Know
Meta Title: Will Commissions Count Towards a Loan?
Meta Description: One of the most common questions I hear from prospective home buyers goes something like this: “I made $40,000 last year and $20,000 of that was commission/bonus income. Can I use that the commission income to qualify for a home loan?” For many people who work in sales positions, commission-based income is a fact of life.
Canonical URL: https://azmortgagebrothers.com/get-part-income-commission-can-use-qualify-loan/
H1: Will Commissions Count Towards a Loan?

One of the most common questions I hear from prospective home buyers goes something like this: “I made $40,000 last year and $20,000 of that was commission/bonus income. Can I use that the commission income to qualify for a home loan?”

For many people who work in sales positions, commission-based income is a fact of life. If you’re successful at your job, you can make a good living from commissions, but lending rules sometimes make this income difficult to use in the event that you want to qualify for a mortgage.

Unsure If Your Commissions Count for a Loan?

Learn how lenders calculate commissions and what you need to qualify for a mortgage with variable income.

Get a Free Mortgage Consultation

People who do not receive commission but do receive regular bonuses fall into the same category. Regular bonuses are treated the same way as commission for income verification purposes.

So, the question is, “Can I use my commission income to qualify for a home loan?”

Answer: It depends on the loan program.

Let’s take a look at a couple of the most common types of loan programs and their requirements.

## FHA Loans requirements to use Commission Income

- Borrower must have received at least one commission check from their current employer
- Borrower must have at least 12 months of consistent commission income, that means no job gaps greater than 30 days. If the borrower changed jobs within the last 12 months, the new job must be in a similar line of work as the borrower’s past employment.
- Copies of tax returns for the previous two years
- A copy of borrower’s most recent pay stub

## VA Loan requirements to use Commission Income

- Borrower must have received at least one commission check from their current employer
- Borrower must have at least 2 years of consistent commission income, that means no job gaps greater than 30 days. If the borrower changed jobs within the last 24 months, the new job must be in a similar line of work as the borrower currently is in.
- Copies of tax returns for the previous two years
- A copy of borrower’s most recent pay stub

## Conventional Loan requirements to use Commission Income

- Borrower must have received at least one commission check from their current employer
- Borrower must have at least 12 months of consistent commission income, that means no job gaps greater than 30 days. If the borrower changed jobs within the last 12 months, the new job must be in a similar line of work as the borrower’s past employment.
- Copies of tax returns for the previous two years if your commission income represents 25% or more of your total income
- A copy of borrower’s most recent pay stub

## Keep in Mind

- Any documented decrease in commission income from one year to the next would require a good explanation letter from an employer explaining the temporary nature of the changes impacting income.
- Unreimbursed business expenses must be subtracted from gross income

## Conclusion

In Conclusion, the Good News is ‘YES’, you can use commission income to qualify for a home loan.

The requirements are somewhat more stringent than they would be for non-commission income, but these are in everyone’s interest. They establish the consistency of income and ensure that there’s enough coming in on a regular basis to pay the bills and keep the lights on.

Talk to your lender if you’d like to see if you can use your commission income to get a home mortgage. If you don’t have a lender yet, contact us today, and we’ll walk you through it. You may just qualify for more than you think.

## We’re Here To Help!

Contact Us Today at 602-535-2171

Or reach us using our contact form

Or Complete our Inquiry Form

Learn how you can use part of your commission income to qualify for a mortgage and expand your financing options. Enhance your financial strategy by exploring how to relocate and secure a mortgage while working remotely, understanding how a rapid rescore can improve your loan qualification, considering the benefits of a DSCR loan as a hard money alternative, and getting expert advice on counting commissions and bonuses effectively.

---

## Transcript of the Mortgage Brothers Podcast

### How to Count Commissions, Bonuses, and Tips for a Mortgage

(00:02) 🎙 Welcome to the Mortgage Brothers Podcast! I’m Eddie Knoell, and I’m Tom Knoell.

Today, we’re covering a big topic for many borrowers:

💰 How do lenders count commissions, bonuses, and tips as income?

If you earn commissions, bonuses, or tips, you might be wondering:

- Can I use this income to qualify for a mortgage?
- How long do I need to show this income?
- What are the rules for different loan types?

Let’s break it all down!

### Commissions & Bonuses: How Do They Count?

(00:41) 📌 Lenders need to see a history of commissions & bonuses before counting them as income.

🏦 Loan Type Rules:
✅ Conventional Loans (Fannie Mae/Freddie Mac) – 12 months of history required.
✅ VA Loans – 24 months of history required (same employer, no gaps).
✅ FHA Loans – 12 months of history required (must be from one employer).

🚀 Multiple Employers?

- Conventional loans allow you to combine income from multiple employers (as long as it’s in the same field).
- VA & FHA loans require the same employer for the required period.

📌 Example:
If you earned commission selling water filters for 6 months, then switched jobs and earned commission selling home appliances for 6 months, that can count for conventional loans (since it’s a similar industry).

🚨 BUT, if you switched from sales to cutting hair, it wouldn’t count!

### Tips: How Are They Counted?

(03:09) Tip income works differently than commissions and bonuses.

✅ Conventional & VA Loans – 2 years of reported tip income required.
✅ FHA Loans – Only 1 year of reported tip income required.

💡 Think of tip income like self-employment income.

- Lenders want consistent, documented earnings over time.
- This is why VA & Conventional loans require 2 years, while FHA only needs 1 year.

📌 How are tips verified?

- If tips are paid on a credit card, they are reported on your pay stubs and W-2s.
- If you receive cash tips, they only count if you report them on your tax returns.

🚨 Not reporting cash tips?
If your tax returns don’t show tip income, lenders won’t count it, even if you’ve been earning tips for years.

💡 Pro Tip: If you earn tips, make sure they are reported on your pay stubs or tax returns so they can count toward your mortgage qualification!

### Common Myths About Counting Income

🚫 “I’ve been getting tips/bonuses for 9 months—can I use that income?”
No. You need at least 12 months for conventional/FHA loans and 24 months for VA loans.

🚫 “I switched jobs recently—can I still count my commissions?”
Maybe. If you’re in the same industry and it’s a conventional loan, you can combine income from multiple employers. For VA & FHA loans, you need to be with one employer.

🚫 “I get cash tips but don’t report them—will lenders still count them?”
No. Only documented tip income (on pay stubs or tax returns) counts.

### The Bottom Line

✅ Commissions & bonuses require at least 12 months (conventional/FHA) or 24 months (VA).
✅ Tip income requires 2 years (Conventional & VA) or 1 year (FHA).
✅ Always report cash tips on your tax returns if you want them to count toward your mortgage.

💰 Need help figuring out your income for a mortgage?
📩 Contact us for a free consultation!

### Special Podcast Offer 🎁

(06:04) 🎉 Want a $50 Amazon Gift Card?

🦓 Use the secret code word: “Zebra” when you call or request a mortgage quote!

📌 You must be a real person getting a real mortgage quote.

🚀 Get your quote today & claim your gift card!

### Got Questions? Contact Us!

🎯 Need a mortgage? Ask us for a free quote—we’ll guide you through every step!

🏡 Thanks for tuning in—see you in the next episode!
