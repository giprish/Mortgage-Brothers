Original URL: https://azmortgagebrothers.com/what-is-the-difference-between-aan-arizona-condo-and-arizona-townhome/
Page Title: What’s the Difference Between a Condo and a Townhome?
Meta Title: What Is The Difference Between A Condo And A Townhome?
Meta Description: Compare Arizona condo vs townhome ownership, HOA structure, and why lenders treat condos with stricter financing guidelines.
Canonical URL: https://azmortgagebrothers.com/what-is-the-difference-between-aan-arizona-condo-and-arizona-townhome/
H1: What Is The Difference Between A Condo And A Townhome?

There are many developments in Mesa, Tempe, Chandler, Scottsdale, Glendale, and the greater Phoenix area that may appear like condos but they are actually townhomes. They both have similar HOAs and are often marketed to the public as one and the same. Most people think there isn’t a difference between a condo and townhouse but in fact there is a big difference. The difference is in the way ownership is legally structured.

Condo or Townhome—Which Is Right for You?

Not sure whether to buy a condo or a townhome? Get expert insights on costs, ownership, and the best choice for your lifestyle.

Get a Free Homebuying Consultation

## Condo owners

Condo owners have ‘horizontal ownership’, i.e., they own the floor to the ceiling and essentially wall to wall. Condo owners own a pro-rated share of the land they are sitting on. If there are 100 units in a development, each unit owner owns a 1/100 share of the entire plot of land for the development, including all the common areas. Condo developments can be 1 story buildings to any number of stories. In Arizona, it is rare to see condos with more than 2 stories unless you go to downtown Phoenix, Scottsdale, Tempe, and other urban centers that are building high rise condos.

## Townhouse owners

Townhouse owners have ‘vertical ownership’, i.e., they own the earth below the structure and the air above the roof. Townhouse legal descriptions in Arizona will often have a ‘lot number’. A townhouse owner will never have an owner above or below them. Townhouse owners will often times have a neighbor that shares a common wall. Townhouses in Arizona are often referred to as ‘Patio Homes’.

## Does This Make A Difference To A Home Loan Lender?

Townhouses and Condos are treated very differently from the perspective of a lender. Mortgage guidelines have very strict requirements for condos. Condos have inherently more risk to a lender. The basis of this elevated risk is rooted in prorated ownership that all owners have over common areas and the land beneath the units. FHA requires a special condo approval before they will insure any loan on a condo.

Additionally, conventional (Fannie Mae and Freddie Mac) financing requires all condos to be warrantable, i.e. each condo development has to meet certain requirements similar to FHA. Townhouses on the other hand are treated just like single family residences for the most part when it comes to lending. Arizona mortgage guidelines favor townhouses over condos. Whether the favoritism is justly warranted or not, that is the reality today.

If you have any questions about this or if you have any questions you’d like us to answer on our podcast, you can submit your questions using our contact form or give us a call at(602) 535-2171. Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

•••

Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

Mortgage Brothers LLC does not provide tax, legal, or accounting advice. This material has been prepared for informational purposes only. You should consult your own tax, legal, and accounting advisors before engaging in any transaction. Mortgage Brothers NMLS 1007154, NMLS #210917 and 1618695. Equal housing lender.

Get clarity on the differences between Arizona condos and townhomes. For additional context, review our guide on owner-occupied second homes versus investment properties, explore detached guest home appraisal issues, and discover how connecting a guest house to your main home can enhance value.
