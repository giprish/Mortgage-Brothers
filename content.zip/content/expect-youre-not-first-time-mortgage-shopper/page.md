Original URL: https://azmortgagebrothers.com/expect-youre-not-first-time-mortgage-shopper/
Page Title: Expert Tips for Not-First-Time Mortgage Shoppers
Meta Title: What to Expect When You’re Not a First Time Mortgage Shopper
Meta Description: When you’re moving to Phoenix, or moving up to a new home within the area, one of the first things you need to do before visiting open houses, before finding a real estate agent or even deciding on a neighborhood, is to find a mortgage lender and understand how to secure a loan to buy
Canonical URL: https://azmortgagebrothers.com/expect-youre-not-first-time-mortgage-shopper/
H1: What to Expect When You’re Not a First Time Mortgage Shopper

# What to Expect When You’re Not a First Time Mortgage Shopper

When you’re moving to Phoenix, or moving up to a new home within the area, one of the first things you need to do before visiting open houses, before finding a real estate agent or even deciding on a neighborhood, is to find a mortgage lender and understand how to secure a loan to buy a home.

If you’ve bought a home before, you might have some experience with the process. But the mortgage industry has changed since your last loan. And if you’re new to the Phoenix Valley, you might not know who to call or what the process will look like here.

Here’s an overview of what it’s really like to get a mortgage these days, and what you need to know and do to ensure you get the best loan for you.

Already Experienced? Elevate Your Mortgage Strategy!

If you’re not a first-time mortgage shopper, connect with our experts for advanced tips and personalized solutions to optimize your mortgage journey.

Enhance Your Strategy

## What About Online Lenders?

Depending on when you last applied for a mortgage, the market might have changed a lot, or maybe just a little. One of the biggest changes over the last 10 to 15 years are online lending options. Today, online lenders like Lending Tree and others are buying up ad space on every real estate website, offering incredibly low rates and easy financing.

There are a few things you need to know. First, those rates you’re seeing online? They’re teaser rates – the lowest possible rates that could ever be offered to a buyer that has perfect credit, no outstanding debt, and plenty of cash to pay down points. Unless you fit those criteria (very few people do) the rate you’ll likely get will almost certainly not match what online lender are offering.

Another problem with online lenders is that you cannot develop a personal relationship with them. You might think, “well, I don’t want a relationship, I want a low rate.” The catch is, a personal relationship can often make the difference between getting the house you want, and not getting it.

Why? The ugly truth about online lenders is that their business is all about numbers, not people. That means they are busy processing huge volumes of loans. They’re too busy to answer the phone, too busy to answer questions, too busy to provide needed follow up. This means that closing a loan with an online lender is likely to be fraught with problems and delays. This can cost you big, since if your seller isn’t understanding about this, you could lose your deposit along with the opportunity to buy the home you’ve chosen.

This is why many real estate agents actually advise their buyers against using online lenders. In a multiple offer situation, online lenders can put you at a disadvantage since neither agents nor sellers see them as being reliable or accountable. It’s better to develop a relationship with a lender that you trust, who is known in your local market. A Phoenix-based lending expert like The Mortgage Brothers Team, for instance.

## Choosing a Lender

If you’ve decided against going online for a loan, you’ll need to find a lender you can trust here in the Phoenix Valley. You’ll have plenty of choices, but here are some criteria you should consider:

### Broker or Banker?

A mortgage broker is a person that sells loans that are offered or originated by other lenders. That means they don’t work for any specific lender. Instead, they work for you. They can help you get access to the loans offered through thousands of lenders and programs. A good broker can help you get the best rates available, because they have so many options to choose from.A mortgage banker is a person that works for a lender that is actually originating loans, usually this is a retail bank. They can also have access to some good loans, but ultimately their job is to sell you the loans that their company originates.

Some brokers, by the way, are also bankers. This means that they have access to a wide variety of loans that are offered by other lenders, but also may originate some of their own loans. Another type of lending you should know about is called “portfolio lending.” Where most lenders originate loans and resell them after closing, a portfolio lender originates the loan, and services it after closing. These kinds of loans tend to be ARMs or loans that would be difficult to sell on the open market.

Questions to ask:

- Are you a broker or a bank?
- Do you originate loans?
- Do you offer portfolio lending?

### VA or FHA Approved?

VA and FHA loans offer some of the best rates in the mortgage industry, but because they are government programs they require some expertise on the part of the lender to ensure the process goes smoothly. If you’re a veteran or considering an FHA loan, you should ask the lender whether they are VA or FHA approved.

Why does it matter? Many lenders can offer VA or FHA loans but are not approved lenders. That means they originate loans that are processed elsewhere – these lenders are at a disadvantage since they are less able to resolve issues in a timely way. This can impact your ability to close on time in some cases.

### PreQualified or PreApproved?

The next step before choosing a loan is to find out how much money and what loan programs you might qualify for. There are two approaches to take, one is to get prequalified, which is based on information you verbally tell a lender. It doesn’t involve a credit check or income verification, so the amount you actually qualify for could differ significantly.

Most people in the real estate industry don’t put much stock in a prequalification, but it can offer some good information early in the process. If you’re 6 or more months out from buying a home, a prequalification can be a good choice. If you’re actually ready to look at homes and make offers within the next few months, you’re better off getting pre-approved.

A pre-approval tells sellers and their agents that you are ready, willing and able to actually buy a home for the amount that you’re offering. In fact, many sellers agents tell clients that a pre-qualification is basically worthless. What they want to see, especially in a hot market, is a fully pre-approved offer. In a multiple offer situation, having a solid pre-approval from a lender with a good reputation can make the difference between being accepted, or not.

To get pre-approved, you will need to provide:

- Social security number – you provide this and your current residence on an application.
- Proof of employment and proof of income – this is usually your most recent pay stubs.
- Tax Information – Usually, the last two years. Proves ongoing income and stable employment.
- Bank Accounts and Balances – Lenders want to know what assets you already have and whether you have cash to close.

## Finding a Home

Now you’re ready to actually go through the process of finding a home. The first step is to find a reputable real estate agent, if you haven’t already done so. In today’s market, with so much information available online, many buyers think they don’t need an agent but in most cases a good agent is the difference between getting the home you want, and getting skunked. Agents bring valuable insight about which schools and neighborhoods are best in your price range, they know what kind of offers sellers in their area are accepting, and they can also save you a lot of time looking at houses that don’t meet your criteria (some listings look great on paper but are not so great in person).

You should provide your pre-approval information to the agent as soon as you are ready to start looking. They can use this to develop a strategy to help you get the home you want. How will they “market” you to sellers? Will they preview homes for you? This can save time looking at those that aren’t a good fit.

In a hot market, you and your agent should be ready to work quickly to get an offer in on homes that will likely sell fast, and know how to write an offer that wins over the seller. You will likely not have a lot of time to think about a home so you really need to be prepared to write an offer on a home quickly after seeing it.

This is where having a solid pre-approval before you start looking really makes a difference. It helps to ensure that the financial side doesn’t complicate your decision-making. You’ll know whether you can afford the house and the payments involved before you start looking.

## Applying for the Loan

Once you’ve found the house of your dreams, you need to make formal application for your loan within a few days to ensure that you are meeting the terms of your purchase agreement, and to ensure that the lender is able to close on time. Failure to meet these terms can cause you to lose your deposit if you aren’t able to close on time, so this isn’t the time to be shopping rates.

If you’re pre-approved, the lender will have most of the information he or she needs, but they will ask you to update all your information so that it is most recent (new pay stubs, new bank account balances), and you’ll need to fill out a new application. You also need to provide a copy of your purchase and sale contract so that the lender knows what house you are buying and can order a Be ready to move quickly – once that offer is down, you have a lot of timelines that must be met to keep you “in contract.”

## Locking Rates

Once your home is found, the offer is made and your loan application is made, you’ll need to make a decision about locking rates. This is a decision that’s stressful for many people, because of course, you want to get the lowest rate possible.

You’ll want to do a little research about what sort of trend line rates are following to know where your greatest risk lies. Your mortgage lender can advise you about this. If rates are very low, and starting to trend higher, your risk of missing out on a future dip in rates is outweighed by the likelihood that rates will go up, so locking in quickly is the best choice. If the trend is downward, you might be better off to “float” as long as you can.

In either case, there’s always a risk that something can happen to cause rates to increase – a news item or political event, terrorist attack…you never know. When it comes to “lock or float,” your own personal outlook and comfort with risk is likely to be the determining factor.

## The Lending Process

Once you’ve made formal application and locked a rate, the lender will process the loan. To avoid delays or even the possibility that your loan application will be denied, make sure to:

1. Follow all the terms of your purchase and sale contract. Make sure you fully understand what actions you’re required to take by what dates in order to meet the terms of your contract. Your agent can help with this – many of them provide a calendar of crucial dates for applications, inspections, responses and waivers.
2. Provide all loan materials requested in a timely way. If your mortgage lender asks for a piece of additional information, make sure you respond quickly. Your loan likely cannot be processed and approved without it.
3. Refrain from making any large purchases on credit. DO NOT purchase a car, a boat, a fabulous vacation, or do an expensive renovation of your current home that you plan to sell using a home equity line, credit card or any other form of credit. This will show up on your credit report and can slow or stop your approval. It can wait.

## Final Approval and the Closing Table

Final Approval for a loan will ideally come in at least a week in advance of your closing, and everything will go along merrily towards closing. In the real world, there are often delays in this process. Sometimes these delays are caused by issues on the buyer end – such as buying that boat we cautioned you against – other times, it’s due to a backup at the lender.

During this time, you’ll want to stay in close contact with your lender, your agent and possibly your therapist to ensure that things continue to go smoothly.

A few to-dos for you around closing time include:

- Final inspection of the home 3 – 5 days in advance of closing. The seller’s stuff should be out, or on the way out, by this time. If not, you’ll want to find out why.
- Setting an appointment with your closing attorney or escrow agent to sign all final paperwork.
- Key transfer – agents will often handle this for you.
- Move-in – For your sanity, it’s best to delay your move in until a day or two after closing. Sometimes timelines are tight to leave your old home if you have back to back closings. If necessary, stay in a hotel for a night or two to ensure the house is move in ready.

## Kick Back and Relax – You’re Home!

Once you’ve made it this far, you’ll be able to relax. The house is closed, you’re moved in, maybe you’re beginning to work on upgrades that will make the home yours. Just remember, the loan process has been stressful, but in the end it’s all worth it to get into your new home. So make sure to take some time to celebrate this next step in your life.
