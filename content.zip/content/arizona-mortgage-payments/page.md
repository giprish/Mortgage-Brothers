Original URL: https://azmortgagebrothers.com/arizona-mortgage-payments/
Page Title: Ultimate Guide: Optimize Your Arizona Mortgage Payments
Meta Title: Arizona Mortgage Payments
Meta Description: Unfortunately a major side effect of having a mortgage loan is that you’ll have to pay it back! We wanted to highlight a few points about your upcoming mortgage payment so you can understand what it is you’re paying. See my payment calculator to play around with scenarios. You should receive a mortgage payment booklet
Canonical URL: https://azmortgagebrothers.com/arizona-mortgage-payments/
H1: Arizona Mortgage Payments

# Arizona Mortgage Payments

Unfortunately a major side effect of having a mortgage loan is that you’ll have to pay it back! We wanted to highlight a few points about your upcoming mortgage payment so you can understand what it is you’re paying. See my payment calculator to play around with scenarios.

Streamline Your Payments Today!

Now that you’ve explored key strategies for Arizona Mortgage Payments, connect with our specialists for personalized mortgage advice.

Contact Us Now

You should receive a mortgage payment booklet or instructions on how to pay your Arizona mortgage loan online. If that doesn’t arrive before your first payment, you should have at least received a temporary payment coupon with your closing documents.

Generally the payments will be due at the beginning of the month and mortgage lenders begin assessing late fees on the 15th of the month.

When you receive your first bill, here are a few things you will see:

- Principal Amount: This is the portion that goes toward paying down your balance.
- Interest: Essentially this is the amount you’re paying to the bank to borrow the original balance.
- Taxes: Real Estate Taxes can either be included as part of your monthly payment or they can be paid separately throughout the year. Make sure you understand this requirement before closing!
- Insurance: This is your hazard insurance (fire) which protects your home and belongings.
- Mortgage Insurance: Depending on the type of Arizona mortgage loan you have, this will be an additional payment that’s unrelated to your hazard insurance. Lenders often require this when the Loan to Value is greater than 80% and is meant to protect the lender if the borrower fails to pay back the loan.

## Frequently Asked Questions

### What is an Impounded or Escrow Account?

Loans are made up of Principal, Interest, Taxes and Insurance (PITI). The escrow account covers the T and the I and is included in the monthly payment.

### Are Impound Accounts required?

In some cases yes, as with Government Loans, FHA and VA loan programs. In other cases, if the Loan to Value is low enough an escrow waiver is allowed but there’s typically a higher mortgage rate due to the lender taking on more risk.

### If I refinance my existing Arizona mortgage loan, what happens to my impound/escrow account?

If there is a balance after the refinance, the excess is generally refunded back to the homeowner.

### Can I set up an escrow account later?

Yes, you can request an escrow account at anytime. Keep in mind that you’ll have to deposit at least 12 months of hazard insurance as well as around 6 months of tax payments in the account in order to get it established.
