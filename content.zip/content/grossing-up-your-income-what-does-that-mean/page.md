Original URL: https://azmortgagebrothers.com/grossing-up-your-income-what-does-that-mean/
Page Title: Grossing Up Your Income - What Does That Mean?
Meta Title: Grossing Up Your Income… what does that mean?
Meta Description: Understand how lenders gross up non-taxable income by 15–25% for FHA and conventional loans to improve mortgage qualification.
Canonical URL: https://azmortgagebrothers.com/grossing-up-your-income-what-does-that-mean/
H1: Grossing Up Your Income… what does that mean?

by

| Feb 4, 2025

You can think of grossing up as extra credit. Now, this isn’t extra money. It doesn’t go into your bank account, but it is an additional amount we can put on paper when it comes to applying for a loan.

Need to Boost Your Qualifying Income?

Grossing up non-taxable income can help you qualify for a mortgage. Find out if this strategy can work for you.

Get a Free Mortgage Consultation

## What’s an example of grossing up?

Say you make $1000 a month from foster care income. Foster care income, because it is non-taxable income, is almost always able to be grossed up. If you’re applying for a convention loan, you’d be able to gross up by 25% and if you’re applying for an FHA loan, you’d be able to gross that up by 15%. So, on the loan application, we’d list that income as $1250 or $1150 respectively.

## What other incomes are typically allowed to be grossed up?

You are able to gross up incomes that are not taxed. The reason you are able to get “extra credit” on these nontaxable incomes is that there is less burden on them.

Other gross up able incomes include:

- Child Support Payments
- VA Benefits
- Workers’ Compensation
- Supplemental Social Security
- Adoption Income
- Foster Care Income

You should be aware though, that these incomes do not show up on your tax return, so you’re going to have to help your lender out by getting the required documentation from these sources and you’re also going to have to prove that you are going to continue to receive this income for the next three years.

There’s also income that is sometimes or partially able to be grossed up.

## What income may be grossed up?

For some incomes, a portion of them is not taxable. These non-taxable portions can be grossed up. This applies to the following:

- Social Security Income
- Retirement Income
- Pension income
- Annuity Income
- IRA Distribution Income
- Housing Allowance Income
- Long Term Disability Income

Each of these shows up on tax returns, and whatever portion of it is not taxable we can take that amount and gross it up 25% for conventional loans and 15% for FHA.

If you have any questions about this or if you have any questions you’d like us to answer on our podcast, you can submit your questions using our contact form or give us a call at(602) 535-2171. Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

•••

Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

Mortgage Brothers LLC does not provide tax, legal, or accounting advice. This material has been prepared for informational purposes only. You should consult your own tax, legal, and accounting advisors before engaging in any transaction. Mortgage Brothers NMLS 1007154, NMLS #210917 and 1618695. Equal housing lender.

Wondering what it means to gross up your income for mortgage qualification? For a complete picture, explore our insights on spouse-related mortgage issues, learn how car loan payments can impact your mortgage, review the possibility of getting a third mortgage, and understand closing pace requirements.

---

## Transcript of the Mortgage Brothers Podcast

### Grossing Up Your Income: What Does It Mean & How Can It Help You?

### Introduction

[00:02]Welcome to the Mortgage Brothers Podcast! I’m Eddie Knoell, and I’m Tom Knoell. In this episode, we’re answering a question many borrowers don’t know they should ask:

👉 What is grossing up income?👉 How can it help with your mortgage approval?👉 Which types of income qualify for grossing up?

If you’ve heard the term “grossing up” while applying for a mortgage, you’re in the right place!

### What Does “Grossing Up” Mean?

[00:39]If you receive certain types of non-taxable income, lenders may allow you to increase that income on paper to improve your loan eligibility.

💡 Think of it as getting extra credit for your income.

When we gross up your income, we adjust your earnings to reflect what they would be if they were taxed—since non-taxable income allows you to keep more money in your pocket.

### Example of Grossing Up Income

[01:43]Let’s say you receive $1,000 per month from foster care income:✔️ Conventional Loan → Gross up by 25% → Adjusted income: $1,250✔️ FHA Loan → Gross up by 15% → Adjusted income: $1,150❌ VA Loans → No grossing up allowed

📌 Bottom line: The lender considers your non-taxable income as being higher than what you actually receive, giving you a better debt-to-income (DTI) ratio and potentially increasing your borrowing power.

### Why Are Some Incomes Eligible for Grossing Up?

[03:34]Lenders allow non-taxable income to be grossed up because you don’t pay taxes on it—meaning you effectively have more disposable income than someone earning a taxable equivalent.

Think of your income as ice cream flavors:🍦 Net Income (Vanilla): The amount deposited in your bank account after taxes.🍫 Gross Income (Chocolate): Your salary before taxes.🍓 Grossed-Up Income (Strawberry): The bonus credit given for non-taxable income.

When applying for a mortgage, lenders usually use your gross income (before taxes). However, for non-taxable income, they gross it up to compensate for the lack of taxes.

### Types of Income That Can Be Grossed Up

[05:19]

✅ Always Eligible for Grossing Up:These types of income are never taxed, so they can always be grossed up:✔️ Child Support Payments✔️ VA Disability Benefits✔️ Workers’ Compensation✔️ Supplemental Social Security (SSI)✔️ Adoption Income✔️ Foster Care Income✔️ Military Housing Allowance

📌 Note: These incomes do not appear on tax returns, so borrowers must provide separate documentation proving they receive them.

✅ Sometimes Eligible for Grossing Up:These income sources may be taxed partially or fully. Lenders will check how much of it is non-taxable and apply the gross-up only to that portion:✔️ Social Security Income✔️ Retirement Income✔️ Pension Income✔️ Annuities✔️ IRA Distributions✔️ Long-Term Disability Income

📌 Example: If one-third of your Social Security income is non-taxable, only that portion is eligible for grossing up.

### How Much Can Your Income Be Grossed Up?

[02:53]

✅ Conventional Loans: 25% gross up✅ FHA Loans: 15% gross up❌ VA Loans: No grossing up allowed

📌 Example CalculationIf your pension income is $2,000 per month and half of it is non-taxable, then:✔️ Non-Taxable Portion: $1,000✔️ Grossed-Up Amount (Conventional Loan, 25%): $1,250✔️ New Total Income Used for Mortgage Approval: $2,250

💡 Result: This extra $250 can improve your debt-to-income ratio and help you qualify for a better loan.

### Why Grossing Up Income Matters for Borrowers

[07:34]

Many borrowers don’t realize:🔹 A higher income means qualifying for a bigger home loan.🔹 Lower debt-to-income ratio (DTI) improves mortgage approval chances.🔹 It can help meet lender income requirements without needing a co-signer.

Example:💰 Borrower A: Earns $3,000/month (fully taxable)💰 Borrower B: Earns $3,000/month (but $1,000 is non-taxable Social Security)

📌 With grossing up, Borrower B’s income is adjusted to $3,250 (or more), making them eligible for a higher mortgage amount!

### How to Use Grossing Up to Your Advantage

[08:02]If you receive Social Security, child support, VA benefits, or other non-taxable income, here’s what to do:

✅ Tell your lender upfront if any of your income is non-taxable.✅ Provide documentation (award letters, benefit statements, court orders).✅ Check your tax returns to see which portions of income are taxed vs. non-taxed.✅ Ask your lender how grossing up can improve your mortgage approval.

📌 Remember: The lender only applies grossing up to the non-taxable portion, so understanding how much of your income qualifies is key.

### Final Takeaways: Should You Ask Your Lender About Grossing Up?

[08:36]✅ If you have non-taxable income, grossing up can help you qualify for a bigger loan!✅ It reduces your debt-to-income ratio, making mortgage approval easier.✅ It’s a strategy many borrowers miss, but it can significantly impact loan eligibility.

💡 Even if you’re not sure whether your income qualifies, ask your lender!

### Need Help? Contact Us Today!

[09:02]If you’re applying for a mortgage and want to know how grossing up your income could help, we’re here to assist!

📞 Contact us: Contact Form📞 Call us for a personalized mortgage review

📺 Like & Subscribe for More Mortgage Tips!If you found this information helpful, subscribe to our channel and hit the notification bell for expert insights.

💡 Final Thought: Grossing up income is a simple but powerful tool that can help you secure the home loan you need. Make sure you’re using it to your advantage!
