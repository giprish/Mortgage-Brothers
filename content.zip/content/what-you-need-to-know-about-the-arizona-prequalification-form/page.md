Original URL: https://azmortgagebrothers.com/what-you-need-to-know-about-the-arizona-prequalification-form/
Page Title: Arizona Prequalification Form: Key Facts for Homebuyers
Meta Title: What You Need to Know About the Arizona Prequalification Form
Meta Description: Learn how the Arizona Prequalification Form works, key line items buyers and agents should review, and how a strong form helps in competitive markets.
Canonical URL: https://azmortgagebrothers.com/what-you-need-to-know-about-the-arizona-prequalification-form/
H1: What you need to know about the Arizona Prequalification Form

by

| Feb 4, 2025

We highlight the important line items that borrowers and realtors need to look at in the Arizona Prequalification form. We talk about the advantage of showing a higher loan amount on the prequalification form to show strength if it is a competitive market and multiple offers are expected on homes for sale. We discuss the importance of borrowers sending income and asset documentation so sellers can feel confident in the buyer’s ability to qualify.

Ready to Get Prequalified for a Mortgage?

The Arizona Prequalification Form is your first step to buying a home. Get expert help completing it and securing your mortgage approval.

Start Your Prequalification Today

## Transcript of the Mortgage Brothers Podcast: What You Need to Know About the Arizona Prequalification Form

### Introduction

[00:05]Welcome to the Mortgage Brothers Podcast Show! I’m Eddie Knoell, and I’m Tom Knoell. In this episode, we’re breaking down the Arizona Prequalification Form—what it is, how it works, and why it’s important for homebuyers, sellers, and real estate agents.

Did you know that about 5,000 prequalification forms are exchanged between buyers and sellers every month in Maricopa and Pinal counties alone? Yet, many people don’t fully understand what this form is or how it works. That’s why we’re here today.

### What is the Arizona Prequalification Form?

[00:38]The Arizona Prequalification Form is a document required in real estate transactions in Arizona. It’s issued by lenders and shows that a buyer has been reviewed and is financially capable of purchasing a home.

- It is not a lender-specific form—it’s a universal document used by all banks and lenders in Arizona.
- It is required by real estate agents to submit an offer.
- It provides sellers with proof that a buyer has been financially vetted.

### Prequalification vs. Preapproval

[02:20]There’s often confusion between prequalification and preapproval:

- Prequalification means a lender has reviewed basic financial information but has not verified all documents.
- Preapproval means the loan has been conditionally approved after an underwriter has reviewed all required documentation.

In most cases, a prequalification form serves as a preapproval since lenders review financial documents before issuing it. However, final underwriting approval happens after a contract is signed and the loan process begins.

### How the Prequalification Form Works

[04:37]When a lender issues a prequalification form, it includes:

1. The borrower’s basic details (name, marital status, property type).
2. Loan type (conventional, FHA, VA, etc.).
3. Whether the borrower relies on selling another property to qualify.
4. Whether the borrower needs seller concessions to cover closing costs.

A key part of this form is line 20, which states the maximum loan amount the borrower qualifies for. There is no sales price listed—only the loan amount.

### Key Sections of the Prequalification Form

#### 1. Borrower’s Consultation with a Lender

[05:09]Lines 3, 4, and 5 indicate whether the borrower has consulted with a lender.

- If a borrower has not spoken with a lender, they sign lines 4 and 5.
- If they have consulted a lender, these lines are left blank.

#### 2. Sale Contingencies & Seller Concessions

[06:51]

- Line 8 – Indicates if the buyer needs to sell or lease another property before qualifying for this mortgage.
- Line 9 – Indicates whether the buyer needs seller concessions (closing cost assistance from the seller).

#### 3. Loan Amount vs. Sales Price

[11:09]The form only lists the loan amount, not the home’s sales price. This can sometimes confuse buyers and agents.

#### 4. Interest Rate Limits

[15:32]Line 23 states the maximum interest rate the borrower qualifies for. Most lenders write “market rate” instead of a specific number to prevent confusion.

#### 5. Required Documentation

[17:12]Lines 25-28 indicate whether the borrower has provided:✅ Pay stubs✅ Tax returns✅ W-2s✅ Down payment proof

This is crucial because sellers prefer buyers who have fully documented their financials.

#### 6. Expiration Date

[19:26]The prequalification form expires after 120 days from the date of the credit pull. After that, lenders must re-pull credit and issue a new form.

### Why This Form Matters to Buyers & Sellers

[20:04]For buyers, this form is like a resume—it shows sellers that they are serious and financially qualified.

For sellers, reviewing a buyer’s prequalification form helps them assess risk before accepting an offer. A strong form can give buyers an advantage in a competitive market.

### Final Thoughts

[20:37]

- This form is required in Arizona real estate transactions.
- Lenders, buyers, and agents must ensure it’s accurate before submitting offers.
- If you’re buying a home, work with your lender to maximize your prequalification strength.

### Need Help? Contact Us!

[21:08]If you have any questions about prequalification or the home-buying process, reach out to the Mortgage Brothers Team.

📩 Email us at: Contact Form📞 Call us for a free mortgage quote

If you found this video helpful, like, subscribe, and hit the notification button for more mortgage tips! Thanks for tuning in.

Get the essentials on Arizona’s prequalification form. You might also explore our tips on inspection notices, compare mortgage rates & interest deductions, understand prepayment penalties, learn strategies for buying down rates, consider second mortgage options, and review the latest on capital gains.
