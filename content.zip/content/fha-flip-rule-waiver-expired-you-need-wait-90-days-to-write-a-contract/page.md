Original URL: https://azmortgagebrothers.com/fha-flip-rule-waiver-expired-you-need-wait-90-days-to-write-a-contract/
Page Title: FHA Flip Rule Waiver Expired: 90-Day Waiting Period Returns
Meta Title: FHA Flip Rule Waiver Expired – You need to wait 90 days to write a contract
Meta Description: Are you a buyer getting FHA financing? Make sure to check whether the home you are interested in has been owned by the seller for less than 90 days. Why? Because starting on January 1st 2015, those properties will not be eligible for FHA financing. In 2011, with so many investors purchasing short sale and
Canonical URL: https://azmortgagebrothers.com/fha-flip-rule-waiver-expired-you-need-wait-90-days-to-write-a-contract/
H1: FHA Flip Rule Waiver Expired – You need to wait 90 days to write a contract

by

| Feb 4, 2025

Are you a buyer getting FHA financing? Make sure to check whether the home you are interested in has been owned by the seller for less than 90 days. Why? Because starting on January 1st 2015, those properties will not be eligible for FHA financing.

Buying a Flipped Home? Know the FHA 90-Day Rule

The FHA flip rule waiver is gone, and waiting periods are back. Get expert guidance on navigating the new rules.

Get Expert FHA Loan Advice

In 2011, with so many investors purchasing short sale and foreclosure properties, FHA announced a temporary waiver to the FHA 90 day flip rule allowing financing on flip properties through December 31st 2014.

What this means is that FHA buyers will have to wait until the seller has owned the home for 90 days before they can write a contract on the home. That is important to note. The 90 day waiting period does not mean the buyers have to wait 90 days to close on a FHA, the contract cannot be written before 90 days.

Please contact us if you need any clarification or questions on the FHA 90 day flip rule. We are at your service.

Stay updated on the FHA flip rule waiver and why a 90-day wait is required before writing a contract. For additional context, read about delayed financing, explore an example of a mortgage recast, discover the benefits of an assumable mortgage, and learn how cash offer financing can work for you.
