Original URL: https://azmortgagebrothers.com/buying-or-selling-personal-property-with-your-home-sale-must-watch-this-first/
Page Title: Buying or Selling Personal Property with Your Home Sale?
Meta Title: Buying or Selling personal property with your home sale? Must Watch this First!
Meta Description: Learn why personal property in a purchase contract can trigger lender issues and which Arizona items can transfer with the home sale.
Canonical URL: https://azmortgagebrothers.com/buying-or-selling-personal-property-with-your-home-sale-must-watch-this-first/
H1: Buying or Selling personal property with your home sale? Must Watch this First!

How does Personal Property in a Purchase Contract affect Lenders? Why are we talking about it?

- Avoid pitfalls when personal property is tried to be made part of a purchase contract
- It becomes problematic when it is viewed as a Seller Concession or type of Inducement for Purchase (& Seller just doesn’t CARE and wants it gone!!!)
- Lender wants only the house to be the reason for the purchase because the house is what secures the loan.

Thinking About Including Personal Property in a Sale?

Adding personal property to a home sale can be tricky. Get expert advice to avoid common pitfalls and protect your investment.

Get Expert Real Estate Advice

## What are the basic things to know?

There Two Types of Property:

1. Real Estate

- Buildings & Land
- Real Estate is also items that were purchased as personal property and then affixed to the property. Once you affix it to the property, it becomes a part of Real Estate.
- Example: Built-In Book Case become real estate once they are affixed to the property
- Example: Chandelier become real estate once they are affixed to the property

2. Personal Property (Non-Affixed)

- Can be defined as property that is not attached or affixed to the property.
- Examples: Furniture; Painting; Grill, Lawn-Mower; Dishes, sheets, etc

## What are the basic restrictions to be aware of?

Any Non-Affixed Personal Property besides the following should be handled outside of the purchase contract

In Arizona purchase contract Lines 56 – 60 Dishwasher; Washer-Dryer; Refrigerator; Window Treatments;

If you have any questions about this or if you have any questions you’d like us to answer on our podcast, you can submit your questions using our contact form or give us a call at(602) 535-2171. Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

•••

Be sure to ask us for a free quote on your next mortgage. We’ll personally work with you and help you through the whole process.

Mortgage Brothers LLC does not provide tax, legal, or accounting advice. This material has been prepared for informational purposes only. You should consult your own tax, legal, and accounting advisors before engaging in any transaction. Mortgage Brothers NMLS 1007154, NMLS #210917 and 1618695. Equal housing lender.

Before buying or selling personal property with your home sale, watch this essential guide to make informed decisions. You might also benefit from learning about seller concessions, discovering how to skip two mortgage payments, and checking out our FHA loan gift guide.

---

## Transcript of the Mortgage Brothers Podcast

### Buying or Selling Personal Property with Your Home? Here’s What You Need to Know

(00:02) 🎙 Welcome to the Mortgage Brothers Podcast! I’m Eddie Cannell, and I’m Tom Cannell. This is Episode 18—holy cow, 18 episodes already! Today, we have a must-know topic for both buyers and sellers: personal property and how it affects your home purchase contract.

(00:42) When walking through a home, buyers often fall in love with certain personal items—a pool table, beautiful furniture, or even an outdoor grill. The question is: Can these be included in the home purchase?

🚨 Spoiler Alert: While it might seem convenient for a seller to throw in extra items, lenders have strict rules about what can and cannot be included in a real estate contract.

### Why Does Personal Property Matter in a Real Estate Contract?

(01:14) 💡 Example: When I bought my house a few years ago, the seller had a pool table they didn’t want to move. Sound familiar? Many sellers prefer to sell large or heavy items rather than deal with the logistics of moving them.

(01:46) In many cases, sellers are willing to sell all kinds of personal property, including:
✔️ Pool tables
✔️ Couches, dressers, and beds
✔️ Appliances beyond what’s typically included
✔️ Outdoor furniture, grills, or storage sheds

(02:19) So, what’s the problem?

From a lender’s perspective, personal property should not be part of the real estate transaction. Why?
🔹 Lenders only finance real estate value—not furniture or extras.
🔹 Including personal property artificially inflates the value of the home.
🔹 The home itself is the collateral for the loan—not the pool table or couch!

(02:54) In short, what’s easy for a seller (offloading extra items) is complicated for a lender.

### What Personal Property CAN Be Included in a Home Sale?

(03:34) In Arizona, the Residential Resale Real Estate Purchase Contract (Lines 56-62) addresses personal property. The only items that can be transferred through the contract are:
✔️ Refrigerator
✔️ Washer & Dryer
✔️ Above-ground spa

📌 Anything else should NOT be included in the contract.

(04:15) ❌ Items NOT allowed on the contract:
🚫 Pool tables
🚫 Grills
🚫 Gun safes
🚫 Home furnishings
🚫 Paintings or artwork

(04:53) These personal property items should never be written into:
🔹 The purchase contract
🔹 The additional terms section (Page 7)
🔹 An addendum
🔹 A counteroffer

🔎 Why? Lenders don’t want non-real estate items affecting the home’s appraisal value.

### What If You Write “No Value” for Personal Property?

(05:28) Some buyers and sellers try to get around this rule by writing:
📝 “This personal property has no value.”

💡 This used to work—but NOT anymore.

(06:03) Lenders caught on. If a buyer is including furniture or appliances in the contract, it clearly has value—otherwise, they wouldn’t be asking for it.

✔️ The true real estate value is all that matters.
✔️ Lenders ignore personal property when determining home value.

### What About Outdoor Sheds?

(06:35) What if a shed is included in the home sale?

🔹 If it’s a permanent structure (built into the ground with a foundation), it’s part of real estate.
🔹 If it’s a portable Rubbermaid or Tuff Shed, it’s personal property and should be excluded from the contract.

💡 Rule of Thumb: If the seller could move it to their next home, it shouldn’t be included in the contract.

### How to Handle Personal Property Sales Properly

(07:38) So, what if you really want to buy that pool table or furniture? No problem! Just follow these simple steps:

✔️ Handle the purchase separately—outside of the real estate transaction.
✔️ Create a separate bill of sale between the buyer and seller.
✔️ Keep it out of escrow—don’t include it in closing documents.
✔️ Don’t involve the title company or lender—it’s a private transaction.

📌 Bottom Line: Personal property should be treated as a separate sale, just like buying used furniture from a private seller.

### The Craziest Personal Property Request We’ve Seen

(08:21) 🏡 Wildest Example:
A buyer once wanted to buy a home fully furnished—down to the silverware, bedsheets, and wall décor.

💡 Nice try, but no dice. The lender wouldn’t allow it, and the buyer had to handle it as a separate purchase outside the contract.

(08:53) Can some lenders make exceptions? Maybe. Some real estate agents claim their lender allows personal property to be included, but:
🚨 These deals barely squeak by underwriting.
🚨 It’s risky—the deal could fall apart.
🚨 It’s easier and safer to handle personal property outside of escrow.

### Final Thoughts: Keep Real Estate Separate from Personal Property

(09:25) Key Takeaways:
✔️ Only refrigerators, washers, dryers, and above-ground spas can be included in a contract.
✔️ Everything else should be handled separately—not written into the real estate contract.
✔️ Avoid unnecessary risks—a separate bill of sale is the best approach.
✔️ Title companies and lenders don’t need to see personal property agreements—keep them separate.

(09:57) Final Advice: If you’re buying or selling a home and have questions about personal property, reach out to us!

(10:26) 🎙 Subscribe to the Mortgage Brothers Podcast for more insider mortgage tips and expert advice.

🏡 Need a mortgage? We’re here to help!
